../../../lib/xl2cc_counter.o: xl2cc_counter.c xparameters_ps.h \
 xl2cc_counter.h xpseudo_asm.h xreg_cortexa9.h xpseudo_asm_gcc.h \
 xil_types.h ../../../include/xparameters.h \
 ../../../include/xparameters_ps.h bspconfig.h xl2cc.h
xparameters_ps.h:
xl2cc_counter.h:
xpseudo_asm.h:
xreg_cortexa9.h:
xpseudo_asm_gcc.h:
xil_types.h:
../../../include/xparameters.h:
../../../include/xparameters_ps.h:
bspconfig.h:
xl2cc.h:
