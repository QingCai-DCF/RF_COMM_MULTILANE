#include "p9_crypto.h"

#include <string.h>

typedef struct {
  uint32_t state[8];
  uint64_t total_bytes;
  uint8_t block[64];
  uint32_t block_used;
} p9_sha256_context_t;

static uint32_t p9_rotr(uint32_t value, uint32_t count) {
  return (value >> count) | (value << (32U - count));
}

static uint32_t p9_read_be32(const uint8_t *input) {
  return ((uint32_t)input[0] << 24) | ((uint32_t)input[1] << 16) |
         ((uint32_t)input[2] << 8) | (uint32_t)input[3];
}

static void p9_write_be32(uint8_t *output, uint32_t value) {
  output[0] = (uint8_t)(value >> 24);
  output[1] = (uint8_t)(value >> 16);
  output[2] = (uint8_t)(value >> 8);
  output[3] = (uint8_t)value;
}

static void p9_sha256_transform(p9_sha256_context_t *context,
                                const uint8_t block[64]) {
  static const uint32_t constants[64] = {
      UINT32_C(0x428a2f98), UINT32_C(0x71374491), UINT32_C(0xb5c0fbcf),
      UINT32_C(0xe9b5dba5), UINT32_C(0x3956c25b), UINT32_C(0x59f111f1),
      UINT32_C(0x923f82a4), UINT32_C(0xab1c5ed5), UINT32_C(0xd807aa98),
      UINT32_C(0x12835b01), UINT32_C(0x243185be), UINT32_C(0x550c7dc3),
      UINT32_C(0x72be5d74), UINT32_C(0x80deb1fe), UINT32_C(0x9bdc06a7),
      UINT32_C(0xc19bf174), UINT32_C(0xe49b69c1), UINT32_C(0xefbe4786),
      UINT32_C(0x0fc19dc6), UINT32_C(0x240ca1cc), UINT32_C(0x2de92c6f),
      UINT32_C(0x4a7484aa), UINT32_C(0x5cb0a9dc), UINT32_C(0x76f988da),
      UINT32_C(0x983e5152), UINT32_C(0xa831c66d), UINT32_C(0xb00327c8),
      UINT32_C(0xbf597fc7), UINT32_C(0xc6e00bf3), UINT32_C(0xd5a79147),
      UINT32_C(0x06ca6351), UINT32_C(0x14292967), UINT32_C(0x27b70a85),
      UINT32_C(0x2e1b2138), UINT32_C(0x4d2c6dfc), UINT32_C(0x53380d13),
      UINT32_C(0x650a7354), UINT32_C(0x766a0abb), UINT32_C(0x81c2c92e),
      UINT32_C(0x92722c85), UINT32_C(0xa2bfe8a1), UINT32_C(0xa81a664b),
      UINT32_C(0xc24b8b70), UINT32_C(0xc76c51a3), UINT32_C(0xd192e819),
      UINT32_C(0xd6990624), UINT32_C(0xf40e3585), UINT32_C(0x106aa070),
      UINT32_C(0x19a4c116), UINT32_C(0x1e376c08), UINT32_C(0x2748774c),
      UINT32_C(0x34b0bcb5), UINT32_C(0x391c0cb3), UINT32_C(0x4ed8aa4a),
      UINT32_C(0x5b9cca4f), UINT32_C(0x682e6ff3), UINT32_C(0x748f82ee),
      UINT32_C(0x78a5636f), UINT32_C(0x84c87814), UINT32_C(0x8cc70208),
      UINT32_C(0x90befffa), UINT32_C(0xa4506ceb), UINT32_C(0xbef9a3f7),
      UINT32_C(0xc67178f2)};
  uint32_t words[64];
  uint32_t a, b, c, d, e, f, g, h;

  for (uint32_t index = 0U; index < 16U; ++index)
    words[index] = p9_read_be32(block + 4U * index);
  for (uint32_t index = 16U; index < 64U; ++index) {
    uint32_t x = words[index - 15U];
    uint32_t y = words[index - 2U];
    uint32_t s0 = p9_rotr(x, 7U) ^ p9_rotr(x, 18U) ^ (x >> 3U);
    uint32_t s1 = p9_rotr(y, 17U) ^ p9_rotr(y, 19U) ^ (y >> 10U);
    words[index] = words[index - 16U] + s0 + words[index - 7U] + s1;
  }
  a = context->state[0]; b = context->state[1];
  c = context->state[2]; d = context->state[3];
  e = context->state[4]; f = context->state[5];
  g = context->state[6]; h = context->state[7];
  for (uint32_t index = 0U; index < 64U; ++index) {
    uint32_t s1 = p9_rotr(e, 6U) ^ p9_rotr(e, 11U) ^ p9_rotr(e, 25U);
    uint32_t choose = (e & f) ^ ((~e) & g);
    uint32_t temp1 = h + s1 + choose + constants[index] + words[index];
    uint32_t s0 = p9_rotr(a, 2U) ^ p9_rotr(a, 13U) ^ p9_rotr(a, 22U);
    uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
    uint32_t temp2 = s0 + majority;
    h = g; g = f; f = e; e = d + temp1;
    d = c; c = b; b = a; a = temp1 + temp2;
  }
  context->state[0] += a; context->state[1] += b;
  context->state[2] += c; context->state[3] += d;
  context->state[4] += e; context->state[5] += f;
  context->state[6] += g; context->state[7] += h;
}

static void p9_sha256_init(p9_sha256_context_t *context) {
  static const uint32_t initial[8] = {
      UINT32_C(0x6a09e667), UINT32_C(0xbb67ae85), UINT32_C(0x3c6ef372),
      UINT32_C(0xa54ff53a), UINT32_C(0x510e527f), UINT32_C(0x9b05688c),
      UINT32_C(0x1f83d9ab), UINT32_C(0x5be0cd19)};
  memcpy(context->state, initial, sizeof(initial));
  context->total_bytes = 0U;
  context->block_used = 0U;
}

static void p9_sha256_update(p9_sha256_context_t *context,
                             const uint8_t *data, size_t size) {
  context->total_bytes += size;
  while (size != 0U) {
    size_t available = 64U - context->block_used;
    size_t take = size < available ? size : available;
    memcpy(context->block + context->block_used, data, take);
    context->block_used += (uint32_t)take;
    data += take;
    size -= take;
    if (context->block_used == 64U) {
      p9_sha256_transform(context, context->block);
      context->block_used = 0U;
    }
  }
}

static void p9_sha256_final(p9_sha256_context_t *context, uint8_t output[32]) {
  uint64_t total_bits = context->total_bytes * UINT64_C(8);
  context->block[context->block_used++] = UINT8_C(0x80);
  if (context->block_used > 56U) {
    memset(context->block + context->block_used, 0, 64U - context->block_used);
    p9_sha256_transform(context, context->block);
    context->block_used = 0U;
  }
  memset(context->block + context->block_used, 0, 56U - context->block_used);
  for (uint32_t index = 0U; index < 8U; ++index)
    context->block[63U - index] = (uint8_t)(total_bits >> (8U * index));
  p9_sha256_transform(context, context->block);
  for (uint32_t index = 0U; index < 8U; ++index)
    p9_write_be32(output + 4U * index, context->state[index]);
}

uint32_t p9_crc32(const uint8_t *data, size_t size) {
  uint32_t crc = UINT32_C(0xffffffff);
  for (size_t index = 0U; index < size; ++index) {
    crc ^= data[index];
    for (uint32_t bit = 0U; bit < 8U; ++bit)
      crc = (crc >> 1) ^ ((crc & 1U) ? UINT32_C(0xedb88320) : 0U);
  }
  return ~crc;
}

void p9_sha256(const uint8_t *data, size_t size, uint8_t output[32]) {
  p9_sha256_context_t context;
  p9_sha256_init(&context);
  p9_sha256_update(&context, data, size);
  p9_sha256_final(&context, output);
}
