# RF_COMM_MULTILANE — P9 Zynq-7010 静止 2-Lane 硬件验证 Goal

## 基于 P8E portable architecture 的单板、双 lane、不可移动硬件最大化验证

```text
DOCUMENT_TYPE: CODEX_EXECUTION_GOAL
STAGE: P9_Z7010_STATIONARY_2LANE_PLATFORM_LIMITED_HARDWARE_VALIDATION
STAGE_CLASS: AUTHORIZED_HARDWARE_STAGE

CANONICAL_BASE_TAG: p8e-pass
P8E_SOURCE_COMMIT: 0c67e7717a5a0fb594a237a05184be65cf748f4f
P8E_EVIDENCE_CHECKPOINT: 57ff1079b10a5c0de156b621820774bbb111c5ee
P8E_TAG_OBJECT: a0c32296eea2fdeb333a313bb28fe4efbb60bea2

RECOMMENDED_BRANCH: p9/z7010-stationary-2lane
RECOMMENDED_WORKTREE: C:\Users\user\Documents\RF_COMM_MULTILANE_P9

HARDWARE_PROFILE: Z7010_2LANE_DEV
FPGA_PART: xc7z010clg400-1
FPGA_BOARD_COUNT: 1
PHYSICAL_LANE_COUNT: 2
TFDU_MODULE_COUNT: 4
ALLOWED_LANE_MASKS: 0x1, 0x2, 0x3
MAX_LANE_MASK: 0x3

HARDWARE_MOVEMENT_ALLOWED: false
ROTATION_ALLOWED: false
OPTICAL_ALIGNMENT_CHANGE_ALLOWED: false
MODULE_SWAP_ALLOWED: false
REWIRING_ALLOWED: false
NETWORK_CABLE_REQUIRED: false
ETHERNET_REQUIRED_FOR_P9_PASS: false

MAX_SINGLE_CONTINUOUS_RUN_SECONDS: 1800
MAX_FORMAL_STATIONARY_SOAK_SECONDS: 1800
P9_RESULT_SCOPE: PLATFORM_LIMITED_PASS
```

本文件是可直接交给 Codex 执行的 P9 Goal。它要求在现有单块 Zynq-7010、2 lane、4 个 TFDU 模块、硬件位置固定不动的条件下，最大限度验证 P8B–P8E 已完成的 portable architecture。

P9 不是最终产品验收。P9 不证明：

```text
Z7020
两个独立 Zynq 节点
8 lane
32 个固定模块
sector bank
ABZ
真实 handover
旋转
600 rpm
Ethernet 端到端
SPI 端到端
最终 GLOBAL_PERMIT 物理电路
最终开放阵列安全
```

P9 的核心价值是把以下内容从“离线/仿真/实现 PASS”推进为“当前 Z7010 静止 2-lane 真实硬件 PASS”：

```text
P8C TFDU safety behavior
P8D selective-repeat / SACK / scheduler
P8E routed Z7010 implementation
real PS ELF
real AXI DMA / DDR / cache ownership
real PL-to-TFDU-to-PL optical path
real 2-lane concurrent protocol
real large-object transfer
real fault recovery
30-minute stationary runtime
```

---

# 1. 当前基线

P8E 已冻结：

```text
P8E_DUAL_TARGET_BUILD_CDC_RESOURCE_TIMING: PASS
MANDATORY_EXIT_GATES: 43/43 PASS
Z7010_2LANE_IMPLEMENTATION: PASS
Z7010_2LANE_ROUTED_TIMING: PASS
Z7010 WNS: 0.136 ns
Z7010 WHS: 0.054 ns
Z7010 TNS: 0
Z7010 LUT: 8095 / 45.99%
Z7010 FF: 4561 / 12.96%
Z7010 BRAM36: 4 / 6.67%
CDC critical: 0
unsafe multibit CDC: 0
REQP-1839: 0
AXI DMA static adapter: PASS
dual-endpoint digital simulation: PASS
software multi-profile offline build: PASS
```

P8C 已冻结：

```text
per-physical-module exact 1 ms sliding duty
strict duty <20%
normal design target <=18%
continuous Txd HIGH <=1 us
TFDU startup wait >=500 us
one local active-high GLOBAL_PERMIT per endpoint
permit drop final RTL TX kill
permit reassert requires explicit re-arm
receive-only operation with permit low
```

当前 canonical 项目状态应保持：

```text
P7_STATIONARY_2LANE_APPLICATION_ACCEPTANCE: PASS
CURRENT_Z7010_PLATFORM_ACCEPTANCE: PLATFORM_LIMITED_PASS
P8_PORTABLE_ARCHITECTURE_STATUS: PASS
Z7020_TARGET_ACCEPTANCE: PENDING_Z7020_HW
ROTATION_ACCEPTANCE: PENDING_FINAL_MECHANICAL
FINAL_PRODUCT_HARDWARE_ACCEPTANCE: PENDING_HW
```

P9 只能扩展当前 Z7010 的 `PLATFORM_LIMITED_PASS`，不能提升最终产品范围。

---

# 2. 当前运行必须具有新的明确授权

本 Goal 本身不代表用户授权。

Codex 只有在用户启动消息中包含以下等价明确声明后，才能执行真实硬件步骤：

```text
我授权 Codex 在 P9_Z7010_STATIONARY_2LANE_PLATFORM_LIMITED_HARDWARE_VALIDATION
范围内执行当前单块 Zynq-7010、2 lane、静止且不可移动硬件的自动化操作。

允许 Codex 自动：
- 构建和冻结 P9 bitstream、XSA、BSP/ELF；
- 启动或连接 hw_server、Vivado Hardware Manager、XSDB/JTAG；
- 识别目标并 program 已冻结 SHA256 的 shutdown/candidate bitstream；
- 下载和运行已冻结 SHA256 的 PS ELF；
- 通过 JTAG/AXI、PS DDR、AXI DMA、寄存器、UART、ILA/VIO 执行测试；
- 使能 TFDU receiver，等待至少 500 us；
- 在 lane mask 0x1、0x2、0x3 上执行受控低风险 TFDU 发射；
- 运行最长 1800 秒的静止 2-lane 测试；
- 执行 JTAG/PS/PL 软件复位和自动恢复；
- 失败、超时、异常或退出时自动关闭全部 TFDU 发射并进入 shutdown。

不允许：
- 移动、旋转、调角、遮挡、交换或重新接线硬件；
- 使用 lane mask >0x3；
- 连接或要求 Ethernet；
- 声称 Z7020、8-lane、旋转或产品最终通过。
```

收到该声明后，Codex 应保存：

```text
evidence/hardware/p9/<run_id>/authorization/user_authorization.txt
evidence/hardware/p9/<run_id>/authorization/authorization_record.json
```

授权记录至少包含：

```text
原始授权文本
时间
stage
允许动作
禁止动作
最大运行时间
硬件 profile
lane mask 上限
source commit
最终冻结 artifact SHA256
```

如果启动消息没有明确授权：

```text
P9_AUTHORIZATION_GATE: FAIL_CLOSED
```

Codex 只允许完成 offline build、artifact freeze 和 dry-run，不得连接硬件。

---

# 3. Worktree 和分支

从 `p8e-pass` 创建独立 P9 worktree。不要在冻结的 P8 worktree 上直接进行硬件阶段修改。

目标：

```text
C:\Users\user\Documents\RF_COMM_MULTILANE_P9
branch: p9/z7010-stationary-2lane
base: p8e-pass
```

Codex 开始时：

```powershell
cd C:\Users\user\Documents\RF_COMM_MULTILANE_P8

git status --short
git cat-file -t p8e-pass
git rev-list -n 1 p8e-pass
git worktree list
```

必须验证：

```text
p8e-pass is annotated tag
p8e-pass target == 57ff1079b10a5c0de156b621820774bbb111c5ee
P8 worktree clean
```

如果 P9 worktree 不存在：

```powershell
git worktree add `
  -b p9/z7010-stationary-2lane `
  C:\Users\user\Documents\RF_COMM_MULTILANE_P9 `
  p8e-pass
```

如果已存在，必须验证：

```text
path correct
branch correct
base contains p8e-pass
no unrelated dirty files
```

不得移动或重写：

```text
p8a-pass
p8b-pass
p8c-pass
p8d-pass
p8e-pass
```

P9 的全部修改、build、artifacts 和 evidence 只能位于 P9 worktree。

---

# 4. 开始前强制 intake

生成：

```text
evidence/generated/p9_repo_intake.md
evidence/generated/p9_repo_intake.json
```

记录：

```text
worktree path
branch
HEAD
p8e-pass tag object/target
git status
PROJECT_CONSTRAINTS.txt SHA256
AGENTS.md SHA256
project_state SHA256
project_requirements SHA256
register map SHA256
active profile SHA256
pinmap SHA256
XDC SHA256
P8E final summary SHA256
P8E artifact manifest SHA256
Vivado/Vitis/xsim/Python/tool versions
hardware authorization presence
start timestamp
```

先运行：

```powershell
$env:NO_HARDWARE = '1'
$env:CURRENT_RUN_HARDWARE_AUTHORIZATION = 'false'

python scripts/run_p8e_dual_target_gate.py --verify-existing --json-summary
python scripts/run_offline_gates.py --include-p8e
git diff --check
```

要求：

```text
P8E_VERIFY_EXISTING: PASS
OFFLINE_REGRESSION: PASS
WORKTREE_CLEAN_BEFORE_P9_CHANGE: true
```

失败时不得进入硬件。

---

# 5. 必读文件

Codex 必须完整读取：

```text
AGENTS.md
PROJECT_CONSTRAINTS.txt
PROJECT_CONSTRAINTS_CHANGELOG.md
PROJECT_STATUS.md

config/project_state.json
config/project_requirements.yaml
config/tfdu_safety.yaml
config/p8d_data_plane.yaml
config/p8e_build_matrix.yaml
config/p8e_clock_reset.yaml
config/register_map/ir_axi_regs.yaml

board_profiles/ACTIVE_PROFILE.json
board_profiles/ax7010_tfdu_j10_j11_pinmap.csv
constraints/active/PORT1.generated.xdc

docs/TFDU6102_SAFETY_SUMMARY.md
docs/tfdu6102_safety_contract.md
docs/TFDU_LANE_PHY_SPEC.md
docs/P8C_TFDU_SAFETY_ARCHITECTURE.md
docs/P7_APPLICATION_PROTOCOL.md
docs/REQUIREMENT_TRACEABILITY_MATRIX.md

P8C completion summary
P8D final summary
P8E final summary
P8E audit report
P7 final hardware summaries
```

同时审计：

```text
z7010_2lane_dev_top
board wrapper
tfdu_lane_phy
4PPM codec
L1 frame
selective-repeat TX/RX
SACK/ACK aggregation
scheduler/migration
AXI-stream front/back ends
DMA adapter
PS driver
BSP/platform generation
host/JTAG tools
hardware authorization wrapper
shutdown script
evidence collectors
```

在 `p9_repo_intake` 中列出实际路径。

---

# 6. 当前物理条件

P9 假定：

```text
one Zynq-7010 board
four TFDU modules
two logical lanes
two A-side TFDU modules
two B-side TFDU modules
stationary optical geometry
existing wiring unchanged
board remains in current position
```

P9 主数据路径是单板双逻辑端点：

```text
PS input buffer
→ AXI DMA / PL A endpoint
→ TFDU A transmitter
→ real optical path
→ TFDU B receiver
→ PL B endpoint
→ AXI DMA / PS output buffer
```

反向确认路径：

```text
PL B ACK/SACK
→ TFDU B transmitter
→ real optical path
→ TFDU A receiver
→ PL A ACK/SACK receiver
→ PS completion
```

反方向 payload 使用独立测试：

```text
PS
→ PL B
→ TFDU B
→ optical
→ TFDU A
→ PL A
→ PS
```

该路径不等于：

```text
两个独立 Zynq 节点
两个独立 PS
真实固定侧/旋转侧产品
最终 32×8 环
```

---

# 7. P9 总体工作包

```text
P9-A  immutable build and authorization
P9-B  safe-idle and target identity
P9-C  TFDU safety and raw physical matrix
P9-D  4 Mbit/s/lane progressive PHY validation
P9-E  selective-repeat/SACK hardware validation
P9-F  real AXI DMA/DDR/cache runtime
P9-G  two-lane scheduler/fault/retry migration
P9-H  RFAP v1/vNext and large-object runtime
P9-I  performance characterization
P9-J  30-minute stationary soak
P9-K  shutdown, evidence freeze and checkpoint
```

---

# 8. P9-A：构建和冻结 immutable artifacts

## 8.1 Artifacts

至少构建：

```text
shutdown/safe-idle bitstream
P9 functional candidate bitstream
XSA
PS platform/BSP
PS ELF
generated register headers
host/JTAG runner package
hardware test configuration
```

推荐 artifacts：

```text
ir_p9_shutdown_z7010.bit
ir_p9_z7010_2lane_candidate.bit
ir_p9_z7010_2lane.xsa
ir_p9_ps_runtime.elf
```

所有正式 artifact 必须复制到内容寻址路径：

```text
artifacts/p9/<source_commit>/<sha256>/<filename>
```

不得从可被覆盖的 Vivado run 路径直接 program。

## 8.2 Build gates

functional candidate 必须通过：

```text
source manifest
canonical XDC only
exact part xc7z010clg400-1
synthesis
opt_design
place_design
phys_opt_design
route_design
setup WNS >=0
hold WHS >=0
TNS=0
unconstrained internal endpoints=0
critical DRC=0
critical methodology=0
CDC critical=0
unsafe multibit CDC=0
REQP-1839=0
P8B mapping regression
P8C safety regression
P8D data-plane regression
post-synthesis safety smoke
PS driver compile/link
BSP/ELF consistency
register map consistency
```

不得因硬件可用而跳过离线 gate。

## 8.3 Manifest

生成：

```text
artifacts/p9/<run_id>/artifact_manifest.json
evidence/generated/p9_artifact_freeze_summary.md
evidence/generated/p9_artifact_freeze_summary.json
```

记录：

```text
source commit
Vivado/Vitis version
exact part
top
profile
pinmap/XDC hashes
register map hash
bitstream hash
XSA hash
BSP hash
ELF hash
build commands
timing/DRC report hashes
```

## 8.4 Two-phase authorization binding

用户可以一次性授权 P9 全阶段，不需要在 artifact 构建后再次人工确认，但 Codex 必须在 program 前将最终 artifact hashes写入 authorization record，并验证：

```text
stage matches
source commit matches
profile matches
bitstream hash matches immutable file
ELF hash matches immutable file
max runtime <=1800
lane mask <=0x3
shutdown artifact exists
```

任何不匹配都必须 fail closed。

---

# 9. P9-B：target identity 和 safe idle

## 9.1 连接顺序

授权和 artifacts 均通过后：

```text
start hw_server if needed
connect JTAG
enumerate targets
verify Zynq-7010 identity
verify single expected target
record cable/server identity
```

不得在 target identity 未确定前 program functional candidate。

## 9.2 先 program shutdown image

首先 program immutable shutdown/safe-idle bitstream。

要求读取或验证：

```text
Txd request = 0
physical Txd output intent = 0
SD request = shutdown
endpoint armed = 0
tx_kill_active = 1
global_permit_effective = 0
lane_tx_permit_mask = 0
outstanding TX = 0
```

这些是内部 readback/ILA/proxy 证据，不得写成外部示波器测量。

## 9.3 Program functional candidate

program candidate 后，在任何发射前检查：

```text
build/profile ID
register map version/hash
source commit/build ID
lane count = 2
physical module count = 4 or current profile value
active lane mask default = 0
endpoint armed = 0
Txd output intent = 0
SD safe state
duty counters valid
startup_done = 0 until enabled
sticky safety faults clear or explicitly handled
```

如果 candidate 自主发射或默认 armed：

```text
P9_SAFE_BOOT: FAIL
立即 program shutdown image
停止正式运行
```

---

# 10. P9-C：TFDU 安全和 raw physical matrix

## 10.1 Safety readback

验证：

```text
Txd active high
Rxd active low
SD active high shutdown
Mode high-speed selection
startup wait >=500 us
continuous-high guard <=1 us
1 ms sliding duty accounting
hard duty <20%
design target <=18%
permit drop kills final TX
reassert requires re-arm
receive-only works with permit/effective TX off
```

当前板可能没有最终 D17 物理 `GLOBAL_PERMIT` 电路。

因此 P9 只允许声明：

```text
Z7010_FINAL_RTL_TX_KILL_AND_PERMIT_SEMANTICS: PASS
GLOBAL_PERMIT_PHYSICAL_IMPLEMENTATION: PENDING_D17
```

不得声明 current board 具备最终产品 permit 物理单故障行为。

## 10.2 Raw idle noise

每个方向先运行受限 idle window：

```text
A_RX_L0
A_RX_L1
B_RX_L0
B_RX_L1
```

记录：

```text
raw pulse count
unexpected pulse count
idle duration
Rxd synchronized state
false frame start count
```

不得因环境存在少量 raw edge 而自动判定协议失败；但必须记录并给出阈值。

## 10.3 Raw pulse matrix

按顺序执行：

```text
AB_L0
BA_L0
AB_L1
BA_L1
```

每个方向：

1. 64-pulse smoke；
2. 1000-pulse deterministic train；
3. 4096-pulse acceptance train；
4. reset counters；
5. start receiver；
6. wait startup；
7. transmit with low duty and long spacing；
8. compare sent/received/extra；
9. shutdown。

建议 acceptance：

```text
sent = 4096
received = 4096
extra pulses during bounded receive window = 0
continuous-high violation = 0
duty violation = 0
shutdown-after = PASS
```

如果物理 receiver存在明确定义的 pulse stretching，但计数不一一对应，应使用经过 P2/P8C验证的 edge-normalizer，并保存原始和规范化计数。

## 10.4 AB_L1 历史状态

`AB_L1` 有 legacy BAD_DIR 历史，因此必须 fresh 验证。

如果 `AB_L1` 失败：

```text
保留失败 evidence
停止 2-lane acceptance
允许继续 lane0-only diagnostic
不得执行 0x3 正式 soak
P9 final <= PARTIAL
```

不得用 P7 历史 PASS 替代当前 candidate 的 fresh test。

---

# 11. P9-D：4 Mbit/s/lane 逐级 PHY 验证

## 11.1 速率阶梯

对每个 lane、每个 payload方向逐级：

```text
1 Mbit/s raw-equivalent profile
2 Mbit/s raw-equivalent profile
4 Mbit/s FIR target
```

不得直接从 safe idle 跳到长时间 4 Mbit/s。

## 11.2 每级测试

至少：

```text
short fixed payload
247-byte max L1 payload
incrementing pattern
PRBS/deterministic pseudorandom
all-zero/all-one edge cases where protocol encoding permits
100 frames smoke
10,000 frames acceptance
```

每个方向记录：

```text
PHY raw configured rate
actual symbol/chip clock
Txd pulse cycles
Rxd pulse window
frames sent
frames received
CRC good
CRC bad
preamble fail
length fail
duplicate
timeout
retry
duty headroom
continuous-high maximum
```

4 Mbit/s 单 lane硬门：

```text
configured PHY raw = 4 Mbit/s
10000 frames sent
10000 frames delivered or acknowledged
CRC bad = 0
retry exhausted = 0
stuck-high violation = 0
duty violation = 0
```

若少量 retry 是通过故障注入产生，不计入 clean run。

## 11.3 两 lane concurrent raw capability

完成 lane0/lane1 单独 4 Mbit/s 后，执行：

```text
lane_mask=0x3
two-lane concurrent 4 Mbit/s/lane configuration
aggregate raw capability=8 Mbit/s
```

该结论是当前 2-lane raw capability，不是应用 goodput。

---

# 12. P9-E：Selective-repeat / SACK 真实硬件验证

## 12.1 Mandatory profile

当前 Z7010 profile：

```text
sequence width >=16
global outstanding >=32
SACK window >=32
bounded retry
ACK aggregation enabled
health-aware scheduler enabled
```

通过 register readback 证明运行时配置。

## 12.2 Clean traffic

执行：

```text
lane0 only
lane1 only
2-lane
A→B payload
B→A payload
```

覆盖：

```text
sequence near wrap
window fill
window drain
out-of-order receive
ACK aggregation
multiple outstanding
backpressure
```

使用直接设置 session/sequence初值或 test mode 在有限运行内跨越：

```text
0xFFFF → 0x0000
```

## 12.3 Fault injection

只允许数字/协议层注入，不移动硬件：

```text
drop one data frame
drop burst of data frames
drop ACK
drop SACK
duplicate data frame
duplicate ACK
reorder frame
stale session
stale path epoch
future sequence
old sequence
timeout
retry exhaustion controlled case
```

必须证明：

```text
duplicate application delivery = 0
stale application commit = 0
descriptor double completion = 0
window deadlock = 0
bounded recovery
next clean transaction succeeds
```

## 12.4 ACK aggregation

记录：

```text
data frames per ACK/SACK
ACK delay
ACK loss recovery
direction switch count
direction quiet time
window occupancy
```

不得回退到每帧反向 ACK 并仍声称 P8D path 通过。

---

# 13. P9-F：真实 AXI DMA / DDR / cache runtime

P8E 只证明 static adapter。P9 必须尝试关闭当前 Z7010上的真实运行：

```text
PS DDR
AXI DMA
AXI-Stream
descriptor rings
cache flush/invalidate
interrupt or polling completion
abort/reset recovery
```

## 13.1 DMA identity

记录：

```text
DMA IP type/version
base addresses
interrupts
HP port
data width
burst settings
ring depth
descriptor alignment
cache line size
BSP driver version
```

## 13.2 TX/RX ring

至少验证：

```text
TX/RX independent rings
ring depth 8
ring depth 32
producer/consumer wrap
generation increment
full/empty
multiple wraps
descriptor single completion
descriptor leak zero
```

如果资源和 BSP 支持，可测试 ring depth 64，但不是当前 Z7010 mandatory。

## 13.3 Payload sizes

至少：

```text
1
2
3
4
7
8
15
16
31
32
63
64
127
128
191
247
256
1024
4096
65536
1048576 bytes
```

较大对象由 RFAP/streaming分片，不作为单 L1 frame。

## 13.4 Cache ownership

分别运行：

```text
cache enabled
cache-disabled diagnostic if supported
aligned buffer
misalignment rejected or handled
multiple adjacent descriptors
```

验证：

```text
CPU flush before TX ownership
CPU invalidate after RX completion
memory barrier
no stale payload
no stale descriptor status
input SHA256 == output SHA256
```

## 13.5 Reset/abort

自动执行：

```text
DMA reset while idle
DMA reset with queued descriptors
abort object with outstanding descriptors
PS application restart
PL data-plane soft reset
stale completion injection
```

恢复后必须成功完成新对象。

无法在当前 BD中集成真实 AXI DMA时：

```text
REAL_AXI_DMA_DDR_RUNTIME: FAIL or BLOCKED_WITH_EXPLICIT_ROOT_CAUSE
```

不得用 JTAG-to-AXI 或 behavioral model替代为 PASS。

---

# 14. P9-G：2-lane scheduler、fault isolation 和 retry migration

## 14.1 Scheduler modes

执行：

```text
lane0-only
lane1-only
equal-weight 2-lane
unequal weights 1:3
unequal weights 3:1
```

统计：

```text
per-lane scheduled frames
per-lane scheduled bytes
per-lane retries
per-lane defer reason
maximum starvation
fairness error
```

等权、同帧长时，长期字节分配差异应落在冻结的小界内。

## 14.2 Lane-unavailable injection

不移动硬件，通过软件/RTL test control注入：

```text
lane0 unavailable
lane1 unavailable
lane recovers
lane fault while queued
lane fault while in flight
duty throttle on one lane
mapping invalid on one lane
```

要求：

```text
healthy lane continues
unacked frame may migrate
acked frame never migrates
sequence unchanged
object integrity preserved
duplicate commit zero
recovery bounded
```

## 14.3 All-lanes unavailable

短时注入：

```text
all lanes unavailable
```

要求：

```text
no new TX
outstanding ownership preserved or deterministically aborted
no deadlock
clear error/status
recovery after one lane returns
```

---

# 15. P9-H：RFAP v1/vNext 和真实 PS runtime

## 15.1 主验收路径

必须使用真实 PS ELF：

```text
host/JTAG loads input into PS memory
→ PS service submits DMA descriptors
→ PL A
→ physical TFDU optical link
→ PL B
→ DMA to PS output memory
→ PS object service reassembly
→ host reads final object
```

JTAG/AXI direct path只能诊断，不能单独满足：

```text
PS_PL_PHY_PL_PS_RUNTIME_PASS
```

## 15.2 RFAP v1

回归：

```text
fragmentation/reassembly
CRC32
SHA256
abort/restart
partial object not published
legacy compatibility
```

## 15.3 vNext

验证：

```text
session epoch
object/stream ID
fragment offset
L2 sequence/SACK
path epoch
large object streaming
stale/replay rejection
atomic publish
```

## 15.4 对象矩阵

至少：

```text
4 KiB
64 KiB
1 MiB
16 MiB streaming if runtime allows
64 MiB streaming target if DDR/runtime allows
```

payload：

```text
all zero
all one
incrementing
deterministic pseudorandom
binary corpus
boundary lengths
```

每个成功对象：

```text
input size == output size
input CRC32 == output CRC32
input SHA256 == output SHA256
missing fragment = 0
unexpected duplicate = 0
partial publish = 0
stale publish = 0
```

## 15.5 Reverse payload direction

至少完成：

```text
A→B object
B→A object
```

不允许只验证数据一个方向、ACK另一个方向，就声称双向对象通过。

---

# 16. P9-I：性能测量

## 16.1 指标分层

必须分别报告：

```text
PHY_RAW_BPS
FRAME_GOODPUT_BPS
APPLICATION_GOODPUT_BPS
PS_TO_PS_OBJECT_GOODPUT_BPS
```

不得将 raw rate当作应用吞吐。

## 16.2 2-lane 模型基线

在硬件前运行 P8D/P8E airtime model，冻结：

```text
Z7010_2LANE_MODELED_FRAME_GOODPUT
Z7010_2LANE_MODELED_APPLICATION_GOODPUT
P9_APPLICATION_GOODPUT_TARGET
```

P9 target必须在硬件运行前写入 config和authorization record，不得测试后调整门槛。

建议：

```text
P9 functional hard gate:
correctness and bounded recovery

P9 performance characterization gate:
measured and fully explained

P9 performance target:
>=70% of frozen 2-lane model under clean stationary conditions
```

如果模型无法输出可信 2-lane值：

```text
P9_PERFORMANCE_CHARACTERIZATION: PASS
P9_APPLICATION_GOODPUT_TARGET: PENDING_WITH_EXPLICIT_MODEL_GAP
```

不得随意写一个事后可达的数字。

## 16.3 测量

分别执行：

```text
lane0
lane1
two-lane
A→B
B→A
short object
large streaming object
```

记录：

```text
airtime
ACK airtime
DMA latency
PS processing latency
queue occupancy
retries
scheduler utilization
application completion
CPU load if available
```

---

# 17. P9-J：30 分钟静止 soak

## 17.1 时间

总运行：

```text
1800 seconds
```

建议：

```text
first 300 s: warm-up and telemetry stabilization
next 1500 s: formal acceptance window
```

不要额外运行 2 小时。

## 17.2 Soak path

必须主要使用：

```text
real PS ELF
real AXI DMA/DDR/cache
real PL protocol
real TFDU optical link
lane mask 0x3
```

循环覆盖：

```text
4 KiB
64 KiB
1 MiB
A→B
B→A
deterministic payloads
periodic lane scheduler variation
bounded digital fault injection outside clean acceptance subwindow
```

正式 clean acceptance subwindow中：

```text
CRC bad = 0
object SHA mismatch = 0
partial publish = 0
duplicate publish = 0
stale publish = 0
retry exhausted = 0
DMA descriptor leak = 0
DMA double completion = 0
deadlock = 0
duty violation = 0
continuous-high violation = 0
safety fault = 0
```

如果环境造成正常 retry：

```text
retry count可以非零
retry exhausted必须为0
错误对象提交必须为0
```

## 17.3 Bounded runtime

硬件 wrapper必须拥有：

```text
max runtime
watchdog
Ctrl+C handler
process exception handler
JTAG error handler
finally shutdown
```

任何异常都必须：

1. 禁止新 TX；
2. 尝试 endpoint shutdown；
3. program shutdown bitstream if communication remains；
4. 记录 shutdown结果；
5. 保留失败 evidence。

---

# 18. Shutdown 规则

每个 hardware子阶段：

```text
shutdown-before
bounded test
shutdown-after
```

最终必须记录：

```text
Txd output intent = 0
endpoint armed = 0
active TX mask = 0
outstanding physical attempt = 0
SD shutdown request active
SHUTDOWN_EXIT=0
or
TFDU_SHUTDOWN_PROGRAMMED
```

如果 candidate状态不可控：

```text
program immutable shutdown bitstream
```

如果 JTAG完全丢失，记录：

```text
SHUTDOWN_UNCONFIRMED_JTAG_LOST
```

并将整个运行标为 FAIL，不得声称安全退出 PASS。

---

# 19. 当前硬件不允许执行的事项

禁止：

```text
移动开发板
移动 TFDU 模块
改变光学角度
遮挡
交换模块
重新插拔 TFDU
修改接线
连接额外 lane
使用 lane mask >0x3
电机/旋转
ABZ物理输入
sector bank
Z7020
Ethernet requirement
SPI peer
外部示波器 claim
外部光功率 claim
2小时运行
产品最终验收
```

如果当前网线已经连接，也不自动纳入 P9。Ethernet需要单独说明和独立测试计划。

---

# 20. Evidence 目录

每次硬件运行使用唯一：

```text
run_id = p9_<UTC timestamp>_<source-short>_<artifact-short>
```

目录：

```text
evidence/hardware/p9/<run_id>/
```

至少包含：

```text
authorization/
artifacts/
target_identity/
safe_idle/
raw_lane_matrix/
phy_rate/
selective_repeat/
sack_ack/
dma_ddr_cache/
scheduler/
fault_injection/
rfap/
performance/
stationary_30min/
shutdown/
raw_logs/
final/
```

生成 summaries：

```text
evidence/generated/p9_repo_intake.md/json
evidence/generated/p9_artifact_freeze_summary.md/json
evidence/generated/p9_authorization_summary.md/json
evidence/generated/p9_target_identity_summary.md/json
evidence/generated/p9_safe_idle_summary.md/json
evidence/generated/p9_tfdu_safety_summary.md/json
evidence/generated/p9_raw_lane_matrix_summary.md/json
evidence/generated/p9_phy_4mbps_summary.md/json
evidence/generated/p9_selective_repeat_summary.md/json
evidence/generated/p9_sack_ack_summary.md/json
evidence/generated/p9_dma_ddr_cache_summary.md/json
evidence/generated/p9_scheduler_migration_summary.md/json
evidence/generated/p9_rfap_runtime_summary.md/json
evidence/generated/p9_performance_summary.md/json
evidence/generated/p9_stationary_30min_summary.md/json
evidence/generated/p9_shutdown_summary.md/json
evidence/generated/p9_evidence_consistency_summary.md/json
evidence/generated/p9_final_summary.md/json
```

原始数据：

```text
Vivado logs
hw_server logs
XSDB logs
PS UART logs
ILA exports
register snapshots
DMA descriptors
counter snapshots
object manifests
CRC/SHA manifests
performance CSV
fault injection trace
shutdown logs
artifact SHA256 manifest
```

Markdown不得替代 raw evidence。

---

# 21. 自动化脚本

新增或更新：

```text
scripts/run_p9_z7010_stationary_2lane.py
tools/run_p9_z7010_stationary_2lane.ps1
```

支持：

```text
--dry-run
--build-only
--authorize-from <file>
--run-id
--bitstream
--shutdown-bitstream
--elf
--max-runtime
--stage
--resume-diagnostic-from
--formal
--json-summary
```

默认：

```text
dry-run
NO_HARDWARE=1
authorization absent -> fail before hw_server
```

必须通过干运行测试：

```text
no authorization -> no hardware connection
wrong bitstream hash -> fail
wrong ELF hash -> fail
wrong XDC/profile -> fail
missing shutdown artifact -> fail
missing max runtime -> fail
lane mask 0x4 -> fail
movement-required stage -> fail
rotation stage -> fail
Ethernet-required stage -> fail
```

---

# 22. Stage 执行顺序

严格按以下顺序：

```text
P9-00 repo intake and P8E recheck
P9-01 offline full regression
P9-02 candidate build and immutable freeze
P9-03 authorization binding and dry-run
P9-04 target identity
P9-05 shutdown image / safe idle
P9-06 functional candidate safe boot
P9-07 TFDU safety readback
P9-08 raw idle/noise
P9-09 AB_L0 raw
P9-10 BA_L0 raw
P9-11 AB_L1 raw
P9-12 BA_L1 raw
P9-13 lane0 1/2/4 Mbit/s
P9-14 lane1 1/2/4 Mbit/s
P9-15 two-lane concurrent 4 Mbit/s/lane
P9-16 selective-repeat clean run
P9-17 SACK/ACK aggregation
P9-18 protocol fault injection
P9-19 real DMA/DDR/cache
P9-20 scheduler and retry migration
P9-21 RFAP v1
P9-22 RFAP vNext/streaming
P9-23 reverse-direction object
P9-24 performance characterization
P9-25 30-minute stationary soak
P9-26 shutdown-after
P9-27 evidence consistency
P9-28 source/evidence commits and tag
```

前一 mandatory stage失败，不得继续更高风险 formal stage。

允许诊断时从最早受影响阶段重跑，但：

```text
不得把旧 run 和新 run 拼成一个 formal PASS
最终 formal run必须在一个run_id内完整覆盖 mandatory hardware stages
```

---

# 23. Mandatory acceptance gates

```text
P8E_BASELINE_RECHECK: PASS
P9_OFFLINE_REGRESSION: PASS
P9_ARTIFACT_PROVENANCE: PASS
P9_CURRENT_RUN_AUTHORIZATION: PASS
P9_TARGET_IDENTITY: PASS

P9_SAFE_IDLE: PASS
P9_SAFE_BOOT: PASS
P9_SHUTDOWN_BEFORE: PASS
P9_SHUTDOWN_AFTER: PASS

Z7010_TFDU_STARTUP_WAIT: PASS
Z7010_CONTINUOUS_HIGH_GUARD: PASS
Z7010_EXACT_DUTY_INTERNAL_ACCOUNTING: PASS
Z7010_FINAL_RTL_TX_KILL: PASS

AB_L0_RAW: PASS
BA_L0_RAW: PASS
AB_L1_RAW: PASS
BA_L1_RAW: PASS

LANE0_4MBPS_RAW_CAPABILITY: PASS
LANE1_4MBPS_RAW_CAPABILITY: PASS
TWO_LANE_8MBPS_RAW_CAPABILITY: PASS

SELECTIVE_REPEAT_32_OUTSTANDING: PASS
SACK_WINDOW_32: PASS
SEQUENCE_WRAP: PASS
ACK_AGGREGATION: PASS
ACK_LOSS_RECOVERY: PASS
DUPLICATE_APPLICATION_DELIVERY_ZERO: PASS
STALE_SESSION_PATH_COMMIT_ZERO: PASS

REAL_AXI_DMA_DDR_RUNTIME: PASS
REAL_CACHE_OWNERSHIP: PASS
DESCRIPTOR_SINGLE_COMPLETION: PASS
DESCRIPTOR_LEAK_ZERO: PASS
RESET_ABORT_RECOVERY: PASS

TWO_LANE_SCHEDULER: PASS
LANE_FAULT_ISOLATION: PASS
RETRY_MIGRATION: PASS
ACKED_FRAME_NEVER_MIGRATES: PASS

PS_PL_PHY_PL_PS_RUNTIME: PASS
RFAP_V1_RUNTIME: PASS
RFAP_VNEXT_RUNTIME: PASS
A_TO_B_OBJECT: PASS
B_TO_A_OBJECT: PASS
OBJECT_CRC32: PASS
OBJECT_SHA256: PASS
PARTIAL_OBJECT_COMMIT_ZERO: PASS

PERFORMANCE_CHARACTERIZATION: PASS
STATIONARY_30MIN: PASS

NO_HARDWARE_MOVEMENT: true
MAX_LANE_MASK_USED: 0x3
EVIDENCE_CONSISTENCY: PASS
```

---

# 24. 非 mandatory / 保持 PENDING 的范围

以下不得阻止 P9 platform-limited functional PASS，但必须准确报告：

```text
ETHERNET_LWIP_RUNTIME:
DEFERRED_NOT_REQUIRED_FOR_THIS_P9_RUN

GLOBAL_PERMIT_PHYSICAL_IMPLEMENTATION:
PENDING_D17

EXTERNAL_TFDU_DUTY_MEASUREMENT:
PENDING_EXTERNAL_MEASUREMENT

REAL_OPTICAL_LINK_BUDGET:
PENDING_FINAL_GEOMETRY_AND_MEASUREMENT

ABZ:
PENDING_HARDWARE

PHYSICAL_HANDOVER:
PENDING_P11

Z7020_TARGET_ACCEPTANCE:
PENDING_Z7020_HW

ROTATION_ACCEPTANCE:
PENDING_FINAL_MECHANICAL

FINAL_PRODUCT_HARDWARE_ACCEPTANCE:
PENDING_HW
```

内部 ILA/counter可以支持 RTL安全行为，但不得被写成外部 pin波形、光功率或系统辐射证据。

---

# 25. P9 结果等级

## 25.1 PASS

只有全部 mandatory gates 通过：

```text
P9_Z7010_STATIONARY_2LANE_PLATFORM_LIMITED_HARDWARE_VALIDATION: PASS
CURRENT_Z7010_PLATFORM_ACCEPTANCE: PLATFORM_LIMITED_PASS
```

## 25.2 PARTIAL

例如：

```text
lane0 fully passes
lane1 raw fails
DMA passes
protocol lane0-only passes
```

应写：

```text
P9_STATUS: PARTIAL
ACTIVE_RELIABLE_LANE_MASK: 0x1
TWO_LANE_ACCEPTANCE: FAIL
```

不得用 degraded模式写成2-lane PASS。

## 25.3 FAIL

以下任一发生：

```text
unsafe boot
shutdown unconfirmed
duty/stuck-high violation
wrong artifact programmed
evidence inconsistency
target identity mismatch
错误对象提交
descriptor double completion
formal soak crash/deadlock
```

必须 FAIL。

---

# 26. 状态和需求追踪

开始时：

```text
current_program_stage:
P9_Z7010_STATIONARY_2LANE_PLATFORM_LIMITED_HARDWARE_VALIDATION

p9_status:
IN_PROGRESS

current_run_hardware_authorization:
true only after validated user authorization
```

完成后若 PASS：

```text
p9_status:
PASS

current_z7010_platform:
PLATFORM_LIMITED_PASS

current_program_stage:
P10A_Z7020_SINGLE_BOARD_MIGRATION
```

仍保持：

```text
z7020_target:
PENDING_Z7020_HW

rotation:
PENDING_FINAL_MECHANICAL

final_product_hardware:
PENDING_HW
```

更新：

```text
config/project_state.json
config/project_requirements.yaml
docs/REQUIREMENT_TRACEABILITY_MATRIX.md
PROJECT_STATUS.md
```

`PROJECT_STATUS.md` 必须生成，不得手工漂移。

---

# 27. 建议新增 requirement IDs

至少：

```text
P9-HW-001 immutable artifact provenance
P9-HW-002 safe boot and shutdown
P9-HW-003 current-run authorization binding

P9-PHY-001 four-direction raw matrix
P9-PHY-002 lane0 4 Mbit/s raw
P9-PHY-003 lane1 4 Mbit/s raw
P9-PHY-004 two-lane 8 Mbit/s raw capability

P9-SAFE-001 500 us startup on hardware
P9-SAFE-002 continuous-high guard on hardware
P9-SAFE-003 exact-duty internal runtime
P9-SAFE-004 permit/final TX kill semantics

P9-L2-001 selective-repeat 32 outstanding
P9-L2-002 SACK/ACK aggregation
P9-L2-003 wrap/loss/reorder/duplicate recovery
P9-L3-001 two-lane scheduler
P9-L3-002 lane fault isolation
P9-L3-003 retry migration

P9-DMA-001 real AXI DMA/DDR
P9-DMA-002 cache ownership
P9-DMA-003 descriptor single completion
P9-DMA-004 reset/abort recovery

P9-RFAP-001 v1 runtime
P9-RFAP-002 vNext runtime
P9-RFAP-003 bidirectional object integrity

P9-SOAK-001 stationary 30-minute runtime
P9-EVID-001 hardware evidence consistency
```

每个 PASS关联：

```text
test ID
run ID
profile
artifact SHA256
source commit
raw evidence
summary
```

---

# 28. 失败处理

遇到任何失败：

1. 停止新 TX；
2. 读取 safety状态；
3. 执行 shutdown；
4. 必要时 program shutdown bitstream；
5. 保存原始日志和 counters；
6. 标记首个失败 stage；
7. 不删除或覆盖失败 evidence；
8. 只修复根因；
9. 重新构建并冻结新 artifact；
10. 新 artifact使用新 hash和新 run ID；
11. 重跑最早受影响 stage；
12. 最终 formal PASS不得拼接多个run。

如果修复修改了：

```text
RTL
XDC
profile
register map
PS ELF
BSP
DMA config
```

必须重新执行全部相应 offline/build gate并生成新 artifact manifest。

---

# 29. Git checkpoint

建议提交：

```text
feat: add P9 Z7010 stationary 2-lane hardware candidate
test: add P9 automated hardware validation and raw evidence
test: freeze P9 platform-limited acceptance checkpoint
```

最终创建：

```text
annotated tag: p9-z7010-2lane-pass
```

标签必须指向最终 evidence checkpoint。

如果 P9 PARTIAL：

```text
tag: p9-z7010-2lane-partial
```

不得使用 `pass`。

完成后：

```powershell
git diff --check
git status --short
```

工作树必须 clean。

---

# 30. 最终输出格式

Codex 终端和 `p9_final_summary.md/json` 输出：

```text
P9_Z7010_STATIONARY_2LANE_PLATFORM_LIMITED_HARDWARE_VALIDATION:
PASS/FAIL/PARTIAL

P8E_BASE_TAG: p8e-pass
P8E_BASE_CHECKPOINT: 57ff1079b10a5c0de156b621820774bbb111c5ee
P9_SOURCE_COMMIT: <hash or NONE>
P9_EVIDENCE_CHECKPOINT: <hash or NONE>
P9_TAG: <tag or NONE>
BRANCH: p9/z7010-stationary-2lane
WORKTREE_CLEAN: true/false

CURRENT_RUN_HARDWARE_AUTHORIZATION: true/false
HARDWARE_ACTIONS_EXECUTED: true/false
NO_HARDWARE_MOVEMENT: true
ROTATION_EXECUTED: false
NETWORK_USED: false
AVAILABLE_LANES: 2
MAX_LANE_MASK_USED: 0x3

TARGET_IDENTITY: PASS/FAIL
ARTIFACT_PROVENANCE: PASS/FAIL
SAFE_BOOT: PASS/FAIL
SHUTDOWN_BEFORE: PASS/FAIL
SHUTDOWN_AFTER: PASS/FAIL

AB_L0_RAW: PASS/FAIL
BA_L0_RAW: PASS/FAIL
AB_L1_RAW: PASS/FAIL
BA_L1_RAW: PASS/FAIL

LANE0_4MBPS_RAW: PASS/FAIL
LANE1_4MBPS_RAW: PASS/FAIL
TWO_LANE_8MBPS_RAW_CAPABILITY: PASS/FAIL

SELECTIVE_REPEAT_32_OUTSTANDING: PASS/FAIL
SACK_WINDOW_32: PASS/FAIL
SEQUENCE_WRAP: PASS/FAIL
ACK_AGGREGATION: PASS/FAIL
RETRY_MIGRATION: PASS/FAIL
LANE_FAULT_ISOLATION: PASS/FAIL

REAL_AXI_DMA_DDR_RUNTIME: PASS/FAIL
REAL_CACHE_OWNERSHIP: PASS/FAIL
DESCRIPTOR_SINGLE_COMPLETION: PASS/FAIL
DESCRIPTOR_LEAK_ZERO: PASS/FAIL

PS_PL_PHY_PL_PS_RUNTIME: PASS/FAIL
RFAP_V1_RUNTIME: PASS/FAIL
RFAP_VNEXT_RUNTIME: PASS/FAIL
A_TO_B_OBJECT: PASS/FAIL
B_TO_A_OBJECT: PASS/FAIL
OBJECT_SHA256: PASS/FAIL
PARTIAL_OBJECT_COMMIT_ZERO: PASS/FAIL

PHY_RAW_BPS_LANE0: <value>
PHY_RAW_BPS_LANE1: <value>
TWO_LANE_RAW_CAPABILITY_BPS: <value>
FRAME_GOODPUT_BPS: <value>
APPLICATION_GOODPUT_BPS: <value>
MODELED_APPLICATION_GOODPUT_BPS: <value>
MEASURED_TO_MODEL_RATIO: <value>

STATIONARY_30MIN: PASS/FAIL
RUNTIME_SECONDS: <value>
OBJECTS_COMPLETED: <value>
BYTES_COMMITTED: <value>
CRC_BAD: <value>
SHA_MISMATCH: <value>
RETRY_EXHAUSTED: <value>
DUTY_VIOLATION: <value>
CONTINUOUS_HIGH_VIOLATION: <value>
DESCRIPTOR_LEAK: <value>
DEADLOCK: <value>

BITSTREAM_SHA256: <sha256>
SHUTDOWN_BITSTREAM_SHA256: <sha256>
XSA_SHA256: <sha256>
PS_ELF_SHA256: <sha256>
ACTIVE_XDC_SHA256: <sha256>
PINMAP_SHA256: <sha256>
REGISTER_MAP_SHA256: <sha256>
PROJECT_STATE_SHA256: <sha256>
PROJECT_REQUIREMENTS_SHA256: <sha256>

PASS:
<list>

FAIL:
<list>

SKIP_WITH_REASON:
<list>

GENERATED_SUMMARIES:
<list>

UNCHANGED_PENDING_SCOPES:
ETHERNET_LWIP_RUNTIME=DEFERRED_NOT_REQUIRED_FOR_P9
GLOBAL_PERMIT_PHYSICAL_IMPLEMENTATION=PENDING_D17
EXTERNAL_TFDU_DUTY_MEASUREMENT=PENDING_EXTERNAL_MEASUREMENT
PHYSICAL_HANDOVER=PENDING_P11
Z7020_TARGET_ACCEPTANCE=PENDING_Z7020_HW
ROTATION_ACCEPTANCE=PENDING_FINAL_MECHANICAL
FINAL_PRODUCT_HARDWARE_ACCEPTANCE=PENDING_HW

NEXT_RECOMMENDED_STAGE:
P10A_Z7020_SINGLE_BOARD_MIGRATION
or
P9_DIAGNOSTIC_REMEDIATION
```

---

# 31. Definition of Done

P9 完成意味着，在当前不可移动单块 Z7010、2 lane、4 TFDU 小板范围内，已经通过真实硬件证明：

```text
P8E Z7010 routed candidate可以安全program和运行；
四个光学方向 fresh raw matrix通过；
两条 lane均可配置并运行4 Mbit/s raw PHY；
两 lane可并发形成8 Mbit/s raw capability；
P8D selective-repeat、32 outstanding、SACK和ACK aggregation在硬件上运行；
lane fault隔离和未确认帧retry migration通过；
真实AXI DMA、DDR和cache ownership通过；
真实PS ELF完成PS→PL→PHY→PL→PS闭环；
RFAP v1/vNext大对象、CRC32、SHA256和原子发布通过；
A→B和B→A对象均通过；
30分钟静止2-lane运行无错误对象、无deadlock、无安全违规；
所有运行绑定immutable artifacts、授权、原始日志和shutdown证据。
```

P9 完成不意味着：

```text
最终 Z7020 产品通过；
两个独立节点通过；
8 lane通过；
32 fixed modules通过；
sector bank通过；
ABZ/handover通过；
旋转/600 rpm通过；
Ethernet/SPI端到端通过；
最终物理GLOBAL_PERMIT通过；
系统光学安全通过；
产品最终验收通过。
```

现在开始执行 P9。不要只返回设计建议。先完成 offline intake、immutable build和authorization gate；只有用户当前运行授权有效后才连接硬件。随后按风险递增顺序实际执行硬件测试、修复可自动修复的问题、生成完整 evidence并提交 checkpoint。
