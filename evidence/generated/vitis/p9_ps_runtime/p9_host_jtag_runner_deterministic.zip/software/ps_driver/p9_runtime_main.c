#include "ir_regs.h"
#include "p9_crypto.h"
#include "p9_runtime_protocol.h"

#include "sleep.h"
#include "xaxidma.h"
#include "xil_cache.h"
#include "xil_io.h"
#include "xparameters.h"
#include "xstatus.h"
#include "xtime_l.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#ifndef IR_PL_BASEADDR
#define IR_PL_BASEADDR UINT32_C(0x43C00000)
#endif

#ifndef XPAR_AXIDMA_0_DEVICE_ID
#error "P9 requires the generated XAxiDma device identity"
#endif

#ifndef XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR
#define XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR UINT32_C(0xffffffff)
#endif
#ifndef XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR
#define XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR UINT32_C(0xffffffff)
#endif

enum {
  P9_STATUS_ENDPOINT_ARMED = 1U << 0,
  P9_STATUS_TX_KILL_ACTIVE = 1U << 1,
  P9_STATUS_OBJECT_ACTIVE = 1U << 2,
  P9_STATUS_OBJECT_DONE = 1U << 3,
  P9_STATUS_OBJECT_FAIL = 1U << 4,
  P9_STATUS_RAW_BUSY = 1U << 7,
  P9_STATUS_RAW_DONE = 1U << 8,
  P9_STATUS_RECEIVER_ENABLE = 1U << 9,
  P9_PHY_READY_MASK = 0x0000000fU,
  P9_PHY_STARTUP_MASK = 0x000000f0U,
  P9_PHY_SAFETY_MASK = 0x00000f00U,
  P9_POLL_DELAY_US = 50U,
  P9_RESET_POLLS = 200000U,
  P9_RFAP_V1_HEADER_BYTES = 32U,
  P9_RFAP_V1_CHUNK_BYTES = 215U,
  P9_RFAP_V1_MAX_USEFUL_BYTES = 8U * 1024U * 1024U,
  P9_RFAP_VNEXT_HEADER_BYTES = 48U,
  P9_RFAP_VNEXT_CHUNK_BYTES = 64U * 1024U,
  P9_DMA_MAX_TRANSFER_BYTES = 0x03ffffffU,
};

typedef struct {
  uint32_t tx_submitted;
  uint32_t tx_completed;
  uint32_t rx_submitted;
  uint32_t rx_completed;
  uint32_t tx_producer_index;
  uint32_t tx_consumer_index;
  uint32_t rx_producer_index;
  uint32_t rx_consumer_index;
  uint32_t tx_producer_generation;
  uint32_t tx_consumer_generation;
  uint32_t rx_producer_generation;
  uint32_t rx_consumer_generation;
  uint32_t tx_ring_full_observed;
  uint32_t rx_ring_full_observed;
  uint32_t tx_ring_empty_observed;
  uint32_t rx_ring_empty_observed;
  uint32_t tx_double_completion;
  uint32_t rx_double_completion;
  uint32_t stale_completion_rejected;
  uint32_t cache_flush_count;
  uint32_t cache_invalidate_count;
  uint32_t memory_barrier_count;
  uint32_t cache_enabled_exercised;
  uint32_t cache_disabled_exercised;
  uint32_t misaligned_transfer_handled;
  uint32_t dma_reset_count;
  uint32_t dma_reset_while_queued_count;
  uint32_t object_abort_count;
  uint32_t pl_soft_reset_count;
  uint32_t shutdown_attempt_count;
  uint32_t shutdown_verified_count;
  uint32_t last_completion_token;
} p9_metrics_t;

static XAxiDma g_dma;
static XAxiDma_Config *g_dma_config;
static uint32_t g_dma_initialized;
static uint32_t g_tx_started;
static uint32_t g_rx_started;
static uint32_t g_ring_depth;
static uint32_t g_cache_enabled;
static p9_metrics_t g_metrics;

static int p9_reset_stream_path(uint32_t depth, uint32_t count_pl_reset,
                                uint32_t count_dma_reset);

static void p9_write_u16_le(uint8_t *output, uint16_t value) {
  output[0] = (uint8_t)value;
  output[1] = (uint8_t)(value >> 8);
}

static void p9_write_u32_le(uint8_t *output, uint32_t value) {
  output[0] = (uint8_t)value;
  output[1] = (uint8_t)(value >> 8);
  output[2] = (uint8_t)(value >> 16);
  output[3] = (uint8_t)(value >> 24);
}

static void p9_write_u64_le(uint8_t *output, uint64_t value) {
  p9_write_u32_le(output, (uint32_t)value);
  p9_write_u32_le(output + 4U, (uint32_t)(value >> 32));
}

static uint16_t p9_read_u16_le(const uint8_t *input) {
  return (uint16_t)((uint16_t)input[0] | ((uint16_t)input[1] << 8));
}

static uint32_t p9_read_u32_le(const uint8_t *input) {
  return (uint32_t)input[0] | ((uint32_t)input[1] << 8) |
         ((uint32_t)input[2] << 16) | ((uint32_t)input[3] << 24);
}

static uint64_t p9_read_u64_le(const uint8_t *input) {
  return (uint64_t)p9_read_u32_le(input) |
         ((uint64_t)p9_read_u32_le(input + 4U) << 32);
}

static uint8_t p9_pattern_byte(uint32_t object_id, uint32_t index) {
  static const uint8_t binary_corpus[32] = {
      0x00, 0xff, 0x55, 0xaa, 0x7e, 0x81, 0x01, 0x80,
      0x10, 0xef, 0x33, 0xcc, 0x0f, 0xf0, 0x5a, 0xa5,
      0x52, 0x46, 0x41, 0x50, 0x00, 0x01, 0xfe, 0xff,
      0x13, 0x37, 0xde, 0xad, 0xbe, 0xef, 0xc3, 0x3c};
  uint32_t mode = object_id >> 28;
  if (mode == 1U) return 0U;
  if (mode == 2U) return 0xffU;
  if (mode == 3U) return (uint8_t)index;
  if (mode == 4U) return binary_corpus[index & 31U];
  uint32_t mixed = (object_id & UINT32_C(0x0fffffff)) ^
                   (index * UINT32_C(0x9e3779b9)) ^ UINT32_C(0xa5c31f27);
  mixed ^= mixed >> 16;
  mixed *= UINT32_C(0x7feb352d);
  mixed ^= mixed >> 15;
  mixed *= UINT32_C(0x846ca68b);
  mixed ^= mixed >> 16;
  return (uint8_t)(mixed >> 24);
}

static uint32_t p9_crc32_update_byte(uint32_t crc, uint8_t value) {
  crc ^= value;
  for (uint32_t bit = 0U; bit < 8U; ++bit)
    crc = (crc & 1U) != 0U ? (crc >> 1) ^ UINT32_C(0xedb88320) : crc >> 1;
  return crc;
}

static uint32_t p9_generated_crc32(uint32_t object_id, uint32_t bytes) {
  uint32_t crc = UINT32_C(0xffffffff);
  for (uint32_t index = 0U; index < bytes; ++index)
    crc = p9_crc32_update_byte(crc, p9_pattern_byte(object_id, index));
  return crc ^ UINT32_C(0xffffffff);
}

static uint32_t p9_pl_read(uint32_t offset) {
  return Xil_In32((UINTPTR)IR_PL_BASEADDR + offset);
}

static void p9_pl_write(uint32_t offset, uint32_t value) {
  Xil_Out32((UINTPTR)IR_PL_BASEADDR + offset, value);
  dsb();
  g_metrics.memory_barrier_count++;
}

static uint64_t p9_time_now(void) {
  XTime value;
  XTime_GetTime(&value);
  return (uint64_t)value;
}

static uint64_t p9_deadline_ms(uint32_t timeout_ms) {
  uint32_t bounded = timeout_ms == 0U ? 120000U : timeout_ms;
  if (bounded > 300000U) bounded = 300000U;
  return p9_time_now() +
         ((uint64_t)bounded * (uint64_t)COUNTS_PER_SECOND) / UINT64_C(1000);
}

static void p9_cache_disable(void) {
  if (g_cache_enabled != 0U) {
    Xil_DCacheDisable();
    g_cache_enabled = 0U;
  }
  dsb();
  g_metrics.memory_barrier_count++;
}

static void p9_cache_enable(void) {
  if (g_cache_enabled == 0U) {
    Xil_DCacheEnable();
    g_cache_enabled = 1U;
  }
  dsb();
  g_metrics.memory_barrier_count++;
}

static void p9_cache_flush(UINTPTR address, uint32_t bytes) {
  Xil_DCacheFlushRange(address, bytes);
  dsb();
  g_metrics.cache_flush_count++;
  g_metrics.memory_barrier_count++;
}

static void p9_cache_invalidate(UINTPTR address, uint32_t bytes) {
  Xil_DCacheInvalidateRange(address, bytes);
  dsb();
  g_metrics.cache_invalidate_count++;
  g_metrics.memory_barrier_count++;
}

static void p9_store_u64(volatile uint32_t *low, volatile uint32_t *high,
                         uint64_t value) {
  *low = (uint32_t)value;
  *high = (uint32_t)(value >> 32);
}

static uint32_t p9_digest_word(const uint8_t digest[32], uint32_t index) {
  const uint8_t *p = digest + 4U * index;
  return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
         ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

static void p9_copy_digest(volatile uint32_t output[8],
                           const uint8_t digest[32]) {
  for (uint32_t index = 0U; index < 8U; ++index)
    output[index] = p9_digest_word(digest, index);
}

static void p9_snapshot_pl(volatile p9_mailbox_t *mailbox) {
  for (uint32_t index = 0U; index < P9_PL_SNAPSHOT_WORDS; ++index)
    mailbox->pl_register_snapshot[index] =
        p9_pl_read(IR_REG_P9_ID + 4U * index);
}

static void p9_capture_terminal_window(volatile p9_mailbox_t *mailbox) {
  /* A full shutdown deliberately asserts abort_all_i in PL and clears the TX
   * next/ACK-base registers.  Capture the completed object's terminal window
   * directly from MMIO before shutdown, then publish the validity marker last.
   * The normal PL snapshot remains a separate, post-shutdown safety record. */
  mailbox->terminal_window_valid = 0U;
  mailbox->terminal_window_command_sequence = mailbox->command_sequence;
  mailbox->terminal_tx_sequence_base = p9_pl_read(IR_REG_P9_TX_SEQUENCE_BASE);
  mailbox->terminal_window_status = p9_pl_read(IR_REG_P9_WINDOW_STATUS);
  dsb();
  mailbox->terminal_window_valid = P9_TERMINAL_WINDOW_VALID;
  dsb();
}

static void p9_copy_metrics(volatile p9_mailbox_t *m) {
  m->tx_submitted = g_metrics.tx_submitted;
  m->tx_completed = g_metrics.tx_completed;
  m->rx_submitted = g_metrics.rx_submitted;
  m->rx_completed = g_metrics.rx_completed;
  m->tx_producer_index = g_metrics.tx_producer_index;
  m->tx_consumer_index = g_metrics.tx_consumer_index;
  m->rx_producer_index = g_metrics.rx_producer_index;
  m->rx_consumer_index = g_metrics.rx_consumer_index;
  m->tx_producer_generation = g_metrics.tx_producer_generation;
  m->tx_consumer_generation = g_metrics.tx_consumer_generation;
  m->rx_producer_generation = g_metrics.rx_producer_generation;
  m->rx_consumer_generation = g_metrics.rx_consumer_generation;
  m->tx_ring_full_observed = g_metrics.tx_ring_full_observed;
  m->rx_ring_full_observed = g_metrics.rx_ring_full_observed;
  m->tx_ring_empty_observed = g_metrics.tx_ring_empty_observed;
  m->rx_ring_empty_observed = g_metrics.rx_ring_empty_observed;
  m->tx_double_completion = g_metrics.tx_double_completion;
  m->rx_double_completion = g_metrics.rx_double_completion;
  m->descriptor_leak_count =
      (g_metrics.tx_submitted >= g_metrics.tx_completed
           ? g_metrics.tx_submitted - g_metrics.tx_completed : 0U) +
      (g_metrics.rx_submitted >= g_metrics.rx_completed
           ? g_metrics.rx_submitted - g_metrics.rx_completed : 0U);
  m->stale_completion_rejected = g_metrics.stale_completion_rejected;
  m->cache_flush_count = g_metrics.cache_flush_count;
  m->cache_invalidate_count = g_metrics.cache_invalidate_count;
  m->memory_barrier_count = g_metrics.memory_barrier_count;
  m->cache_enabled_exercised = g_metrics.cache_enabled_exercised;
  m->cache_disabled_exercised = g_metrics.cache_disabled_exercised;
  m->misaligned_transfer_handled = g_metrics.misaligned_transfer_handled;
  m->dma_reset_count = g_metrics.dma_reset_count;
  m->dma_reset_while_queued_count = g_metrics.dma_reset_while_queued_count;
  m->object_abort_count = g_metrics.object_abort_count;
  m->pl_soft_reset_count = g_metrics.pl_soft_reset_count;
  m->shutdown_attempt_count = g_metrics.shutdown_attempt_count;
  m->shutdown_verified_count = g_metrics.shutdown_verified_count;
  m->last_completion_token = g_metrics.last_completion_token;
}

static void p9_fill_identity(volatile p9_mailbox_t *m) {
  m->pl_id = p9_pl_read(IR_REG_P9_ID);
  m->pl_build_id = p9_pl_read(IR_REG_P9_BUILD_ID);
  m->pl_profile_id = p9_pl_read(IR_REG_P9_PROFILE_ID);
  m->pl_register_map_version = p9_pl_read(IR_REG_P9_REGISTER_MAP_VERSION);
  m->pl_register_map_hash_low = p9_pl_read(IR_REG_P9_REGISTER_MAP_HASH_LOW);
  m->pl_capabilities = p9_pl_read(IR_REG_P9_CAPABILITIES);
  m->dma_device_id = XPAR_AXIDMA_0_DEVICE_ID;
  if (g_dma_config != NULL) {
    m->dma_base_address = (uint32_t)g_dma_config->BaseAddr;
    m->dma_has_sg = (uint32_t)g_dma_config->HasSg;
    m->dma_addr_width = (uint32_t)g_dma_config->AddrWidth;
    m->dma_sg_length_width = (uint32_t)g_dma_config->SgLengthWidth;
    m->dma_mm2s_data_width = (uint32_t)g_dma_config->Mm2SDataWidth;
    m->dma_s2mm_data_width = (uint32_t)g_dma_config->S2MmDataWidth;
    m->dma_mm2s_burst = (uint32_t)g_dma_config->Mm2SBurstSize;
    m->dma_s2mm_burst = (uint32_t)g_dma_config->S2MmBurstSize;
    m->dma_mm2s_dre = (uint32_t)g_dma_config->HasMm2SDRE;
    m->dma_s2mm_dre = (uint32_t)g_dma_config->HasS2MmDRE;
  }
  m->descriptor_alignment = XAXIDMA_BD_MINIMUM_ALIGNMENT;
  m->cache_line_bytes = 32U;
  m->interrupt_mm2s_id = XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR;
  m->interrupt_s2mm_id = XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR;
  m->counts_per_second = COUNTS_PER_SECOND;
}

static int p9_verify_safe_idle(void) {
  uint64_t deadline = p9_deadline_ms(100U);
  do {
    uint32_t status = p9_pl_read(IR_REG_P9_STATUS);
    if ((status & (P9_STATUS_ENDPOINT_ARMED | P9_STATUS_OBJECT_ACTIVE |
                   P9_STATUS_RAW_BUSY | P9_STATUS_RECEIVER_ENABLE)) == 0U &&
        (status & P9_STATUS_TX_KILL_ACTIVE) != 0U)
      return P9_RUNTIME_OK;
    usleep(P9_POLL_DELAY_US);
  } while (p9_time_now() < deadline);
  return P9_RUNTIME_SAFE_IDLE;
}

static int p9_shutdown(void) {
  g_metrics.shutdown_attempt_count++;
  p9_pl_write(IR_REG_P9_CONTROL,
              IR_P9_CONTROL_RECEIVER_DISABLE_MASK |
              IR_P9_CONTROL_DISARM_REQUEST_MASK |
              IR_P9_CONTROL_FULL_SHUTDOWN_REQUEST_MASK);
  int status = p9_verify_safe_idle();
  if (status == P9_RUNTIME_OK) g_metrics.shutdown_verified_count++;
  return status;
}

static int p9_enable_and_arm(void) {
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_RECEIVER_ENABLE_MASK);
  usleep(600U);
  uint64_t deadline = p9_deadline_ms(100U);
  do {
    uint32_t phy = p9_pl_read(IR_REG_P9_PHY_STATUS);
    if ((phy & P9_PHY_SAFETY_MASK) != 0U) return P9_RUNTIME_PHY_NOT_READY;
    if ((phy & (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK)) ==
        (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK))
      break;
    usleep(P9_POLL_DELAY_US);
  } while (p9_time_now() < deadline);
  uint32_t phy = p9_pl_read(IR_REG_P9_PHY_STATUS);
  if ((phy & (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK)) !=
      (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK))
    return P9_RUNTIME_PHY_NOT_READY;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_ARM_REQUEST_MASK);
  deadline = p9_deadline_ms(20U);
  do {
    uint32_t status = p9_pl_read(IR_REG_P9_STATUS);
    if ((status & P9_STATUS_ENDPOINT_ARMED) != 0U &&
        (status & P9_STATUS_TX_KILL_ACTIVE) == 0U)
      return P9_RUNTIME_OK;
    usleep(P9_POLL_DELAY_US);
  } while (p9_time_now() < deadline);
  return P9_RUNTIME_ARM_FAILED;
}

static int p9_dma_wait_reset(void) {
  for (uint32_t poll = 0U; poll < P9_RESET_POLLS; ++poll) {
    if (XAxiDma_ResetIsDone(&g_dma)) return XST_SUCCESS;
    usleep(1U);
  }
  return XST_FAILURE;
}

static int p9_dma_initialize(uint32_t depth, uint32_t count_reset) {
  XAxiDma_Bd template_bd;
  if (depth != 8U && depth != 32U) return P9_RUNTIME_BAD_ARGUMENT;
  if (g_ring_depth != depth) {
    g_metrics.tx_producer_index = 0U;
    g_metrics.tx_consumer_index = 0U;
    g_metrics.rx_producer_index = 0U;
    g_metrics.rx_consumer_index = 0U;
    g_metrics.tx_producer_generation = 0U;
    g_metrics.tx_consumer_generation = 0U;
    g_metrics.rx_producer_generation = 0U;
    g_metrics.rx_consumer_generation = 0U;
  }
  if (g_dma_initialized != 0U) {
    XAxiDma_Reset(&g_dma);
    if (p9_dma_wait_reset() != XST_SUCCESS) return P9_RUNTIME_RESET_FAILED;
    if (count_reset != 0U) g_metrics.dma_reset_count++;
  }
  g_dma_config = XAxiDma_LookupConfig(XPAR_AXIDMA_0_DEVICE_ID);
  if (g_dma_config == NULL || g_dma_config->HasSg == 0 ||
      g_dma_config->HasMm2S == 0 || g_dma_config->HasS2Mm == 0)
    return P9_RUNTIME_DMA_CONFIG;
  if (XAxiDma_CfgInitialize(&g_dma, g_dma_config) != XST_SUCCESS ||
      !XAxiDma_HasSg(&g_dma))
    return P9_RUNTIME_DMA_CONFIG;
  XAxiDma_BdRing *tx = XAxiDma_GetTxRing(&g_dma);
  XAxiDma_BdRing *rx = XAxiDma_GetRxRing(&g_dma);
  XAxiDma_BdRingIntDisable(tx, XAXIDMA_IRQ_ALL_MASK);
  XAxiDma_BdRingIntDisable(rx, XAXIDMA_IRQ_ALL_MASK);
  if (XAxiDma_BdRingCreate(tx, P9_TX_BD_BASEADDR, P9_TX_BD_BASEADDR,
                           XAXIDMA_BD_MINIMUM_ALIGNMENT, depth) != XST_SUCCESS ||
      XAxiDma_BdRingCreate(rx, P9_RX_BD_BASEADDR, P9_RX_BD_BASEADDR,
                           XAXIDMA_BD_MINIMUM_ALIGNMENT, depth) != XST_SUCCESS)
    return P9_RUNTIME_DMA_RING;
  XAxiDma_BdClear(&template_bd);
  if (XAxiDma_BdRingClone(tx, &template_bd) != XST_SUCCESS ||
      XAxiDma_BdRingClone(rx, &template_bd) != XST_SUCCESS)
    return P9_RUNTIME_DMA_RING;
  g_dma_initialized = 1U;
  g_tx_started = 0U;
  g_rx_started = 0U;
  g_ring_depth = depth;
  if (XAxiDma_BdRingGetFreeCnt(tx) == (int)depth)
    g_metrics.tx_ring_empty_observed = 1U;
  if (XAxiDma_BdRingGetFreeCnt(rx) == (int)depth)
    g_metrics.rx_ring_empty_observed = 1U;
  return P9_RUNTIME_OK;
}

static void p9_advance_producer(uint32_t tx) {
  uint32_t *index = tx ? &g_metrics.tx_producer_index :
                         &g_metrics.rx_producer_index;
  uint32_t *generation = tx ? &g_metrics.tx_producer_generation :
                              &g_metrics.rx_producer_generation;
  *index += 1U;
  if (*index >= g_ring_depth) {
    *index = 0U;
    *generation += 1U;
  }
}

static void p9_advance_consumer(uint32_t tx) {
  uint32_t *index = tx ? &g_metrics.tx_consumer_index :
                         &g_metrics.rx_consumer_index;
  uint32_t *generation = tx ? &g_metrics.tx_consumer_generation :
                              &g_metrics.rx_consumer_generation;
  *index += 1U;
  if (*index >= g_ring_depth) {
    *index = 0U;
    *generation += 1U;
  }
}

static int p9_submit_rx(UINTPTR address, uint32_t bytes, uint32_t token) {
  XAxiDma_BdRing *ring = XAxiDma_GetRxRing(&g_dma);
  XAxiDma_Bd *bd;
  if (XAxiDma_BdRingAlloc(ring, 1, &bd) != XST_SUCCESS)
    return P9_RUNTIME_DMA_SUBMIT;
  if (XAxiDma_BdSetBufAddr(bd, address) != XST_SUCCESS ||
      XAxiDma_BdSetLength(bd, bytes, ring->MaxTransferLen) != XST_SUCCESS) {
    (void)XAxiDma_BdRingUnAlloc(ring, 1, bd);
    return P9_RUNTIME_DMA_SUBMIT;
  }
  XAxiDma_BdSetCtrl(bd, 0U);
  XAxiDma_BdSetId(bd, token);
  if (XAxiDma_BdRingToHw(ring, 1, bd) != XST_SUCCESS)
    return P9_RUNTIME_DMA_SUBMIT;
  g_metrics.rx_submitted++;
  p9_advance_producer(0U);
  if (g_rx_started == 0U) {
    if (XAxiDma_BdRingStart(ring) != XST_SUCCESS)
      return P9_RUNTIME_DMA_SUBMIT;
    g_rx_started = 1U;
  }
  return P9_RUNTIME_OK;
}

static int p9_submit_tx(UINTPTR address, uint32_t bytes, uint32_t token) {
  XAxiDma_BdRing *ring = XAxiDma_GetTxRing(&g_dma);
  XAxiDma_Bd *bd;
  if (XAxiDma_BdRingAlloc(ring, 1, &bd) != XST_SUCCESS)
    return P9_RUNTIME_DMA_SUBMIT;
  if (XAxiDma_BdSetBufAddr(bd, address) != XST_SUCCESS ||
      XAxiDma_BdSetLength(bd, bytes, ring->MaxTransferLen) != XST_SUCCESS) {
    (void)XAxiDma_BdRingUnAlloc(ring, 1, bd);
    return P9_RUNTIME_DMA_SUBMIT;
  }
  XAxiDma_BdSetCtrl(bd, XAXIDMA_BD_CTRL_TXSOF_MASK |
                             XAXIDMA_BD_CTRL_TXEOF_MASK);
  XAxiDma_BdSetId(bd, token);
  if (XAxiDma_BdRingToHw(ring, 1, bd) != XST_SUCCESS)
    return P9_RUNTIME_DMA_SUBMIT;
  g_metrics.tx_submitted++;
  p9_advance_producer(1U);
  if (g_tx_started == 0U) {
    if (XAxiDma_BdRingStart(ring) != XST_SUCCESS)
      return P9_RUNTIME_DMA_SUBMIT;
    g_tx_started = 1U;
  }
  return P9_RUNTIME_OK;
}

static int p9_poll_completion(volatile p9_mailbox_t *m, uint32_t token,
                              uint32_t timeout_ms) {
  XAxiDma_BdRing *tx = XAxiDma_GetTxRing(&g_dma);
  XAxiDma_BdRing *rx = XAxiDma_GetRxRing(&g_dma);
  uint32_t tx_done = 0U, rx_done = 0U, pl_done = 0U;
  uint64_t poll_start = p9_time_now();
  uint64_t deadline = p9_deadline_ms(timeout_ms);
  while (p9_time_now() < deadline) {
    XAxiDma_Bd *set;
    int count;
    if (tx_done == 0U &&
        (count = XAxiDma_BdRingFromHw(tx, XAXIDMA_ALL_BDS, &set)) != 0) {
      if (count != 1) g_metrics.tx_double_completion += (uint32_t)(count - 1);
      m->last_dma_tx_status = XAxiDma_BdGetSts(set);
      if ((uint32_t)XAxiDma_BdGetId(set) != token ||
          (m->last_dma_tx_status & XAXIDMA_BD_STS_ALL_ERR_MASK) != 0U)
        return P9_RUNTIME_DMA_COMPLETION;
      if (XAxiDma_BdRingFree(tx, count, set) != XST_SUCCESS)
        return P9_RUNTIME_DMA_COMPLETION;
      g_metrics.tx_completed += (uint32_t)count;
      p9_advance_consumer(1U);
      tx_done = 1U;
      p9_store_u64(&m->dma_tx_completion_ticks_low,
                   &m->dma_tx_completion_ticks_high,
                   p9_time_now() - poll_start);
    }
    if (rx_done == 0U &&
        (count = XAxiDma_BdRingFromHw(rx, XAXIDMA_ALL_BDS, &set)) != 0) {
      if (count != 1) g_metrics.rx_double_completion += (uint32_t)(count - 1);
      m->last_dma_rx_status = XAxiDma_BdGetSts(set);
      m->actual_rx_length =
          XAxiDma_BdGetActualLength(set, rx->MaxTransferLen);
      if ((uint32_t)XAxiDma_BdGetId(set) != token ||
          (m->last_dma_rx_status & XAXIDMA_BD_STS_ALL_ERR_MASK) != 0U)
        return P9_RUNTIME_DMA_COMPLETION;
      if (XAxiDma_BdRingFree(rx, count, set) != XST_SUCCESS)
        return P9_RUNTIME_DMA_COMPLETION;
      g_metrics.rx_completed += (uint32_t)count;
      p9_advance_consumer(0U);
      rx_done = 1U;
      p9_store_u64(&m->dma_rx_completion_ticks_low,
                   &m->dma_rx_completion_ticks_high,
                   p9_time_now() - poll_start);
    }
    uint32_t pl_status = p9_pl_read(IR_REG_P9_STATUS);
    if ((pl_status & P9_STATUS_OBJECT_FAIL) != 0U) {
      m->last_error_detail = p9_pl_read(IR_REG_P9_OBJECT_ERROR);
      return P9_RUNTIME_PL_OBJECT;
    }
    if ((pl_status & P9_STATUS_OBJECT_DONE) != 0U && pl_done == 0U) {
      pl_done = 1U;
      p9_store_u64(&m->pl_completion_ticks_low,
                   &m->pl_completion_ticks_high,
                   p9_time_now() - poll_start);
    }
    if (tx_done != 0U && rx_done != 0U && pl_done != 0U) {
      g_metrics.last_completion_token = token;
      return P9_RUNTIME_OK;
    }
    usleep(P9_POLL_DELAY_US);
  }
  return P9_RUNTIME_DMA_TIMEOUT;
}

static int p9_command_identity(volatile p9_mailbox_t *m) {
  int status = p9_shutdown();
  p9_fill_identity(m);
  if (status != P9_RUNTIME_OK) return status;
  if (m->pl_id != UINT32_C(0x50395a10) ||
      m->pl_build_id != UINT32_C(0x5009000b) ||
      m->pl_profile_id != UINT32_C(0x00701022) ||
      m->pl_register_map_version != IR_REGISTER_MAP_VERSION ||
      m->pl_register_map_hash_low != IR_REGISTER_MAP_HASH_LOW ||
      m->pl_capabilities != UINT32_C(0xf7204221) ||
      m->dma_has_sg != 1U || m->dma_base_address != UINT32_C(0x40400000))
    return P9_RUNTIME_PL_IDENTITY;
  return P9_RUNTIME_OK;
}

static int p9_command_raw(volatile p9_mailbox_t *m) {
  if (m->lane_mask == 0U || m->lane_mask > 3U || m->direction > 1U ||
      m->raw_target == 0U || m->raw_spacing_cycles < 128U)
    return P9_RUNTIME_BAD_ARGUMENT;
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  status = p9_enable_and_arm();
  if (status != P9_RUNTIME_OK) return status;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_CLEAR_COUNTERS_MASK);
  p9_pl_write(IR_REG_P9_RAW_CONFIG,
              (m->lane_mask & 3U) | ((m->direction & 1U) << 8));
  p9_pl_write(IR_REG_P9_RAW_TARGET, m->raw_target);
  p9_pl_write(IR_REG_P9_RAW_SPACING, m->raw_spacing_cycles);
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_START_RAW_MASK);
  uint64_t deadline = p9_deadline_ms(m->timeout_ms == 0U ? 10000U :
                                                            m->timeout_ms);
  status = P9_RUNTIME_RAW_TIMEOUT;
  while (p9_time_now() < deadline) {
    uint32_t value = p9_pl_read(IR_REG_P9_STATUS);
    if ((value & P9_STATUS_RAW_DONE) != 0U &&
        p9_pl_read(IR_REG_P9_RAW_SENT_COUNT) == m->raw_target) {
      status = P9_RUNTIME_OK;
      break;
    }
    if ((p9_pl_read(IR_REG_P9_PHY_STATUS) & P9_PHY_SAFETY_MASK) != 0U) {
      status = P9_RUNTIME_PL_OBJECT;
      break;
    }
    usleep(P9_POLL_DELAY_US);
  }
  int shutdown_status = p9_shutdown();
  return status != P9_RUNTIME_OK ? status : shutdown_status;
}

static void p9_fill_generated_payload(uint8_t *buffer, uint32_t bytes,
                                      uint32_t object_id) {
  for (uint32_t index = 0U; index < bytes; ++index)
    buffer[index] = p9_pattern_byte(object_id, index);
}

static int p9_rfap_transfer_bytes(volatile p9_mailbox_t *m,
                                  uint32_t *transfer_bytes) {
  uint32_t rfap_flags = m->command_flags &
      (P9_FLAG_RFAP_V1_PAYLOAD | P9_FLAG_RFAP_VNEXT_PAYLOAD);
  if (rfap_flags == (P9_FLAG_RFAP_V1_PAYLOAD | P9_FLAG_RFAP_VNEXT_PAYLOAD))
    return P9_RUNTIME_BAD_ARGUMENT;
  uint64_t encoded = m->object_size;
  if (rfap_flags == P9_FLAG_RFAP_V1_PAYLOAD) {
    if (m->object_size > P9_RFAP_V1_MAX_USEFUL_BYTES)
      return P9_RUNTIME_BAD_ARGUMENT;
    uint32_t fragments =
        (m->object_size + P9_RFAP_V1_CHUNK_BYTES - 1U) /
        P9_RFAP_V1_CHUNK_BYTES;
    if (fragments == 0U || fragments > UINT16_MAX)
      return P9_RUNTIME_BAD_ARGUMENT;
    encoded += (uint64_t)fragments * P9_RFAP_V1_HEADER_BYTES;
  } else if (rfap_flags == P9_FLAG_RFAP_VNEXT_PAYLOAD) {
    uint32_t fragments =
        (m->object_size + P9_RFAP_VNEXT_CHUNK_BYTES - 1U) /
        P9_RFAP_VNEXT_CHUNK_BYTES;
    if (fragments == 0U) return P9_RUNTIME_BAD_ARGUMENT;
    encoded += (uint64_t)fragments * P9_RFAP_VNEXT_HEADER_BYTES;
  }
  if (encoded == 0U || encoded > P9_DMA_MAX_TRANSFER_BYTES)
    return P9_RUNTIME_BAD_ARGUMENT;
  *transfer_bytes = (uint32_t)encoded;
  return P9_RUNTIME_OK;
}

static int p9_encode_rfap_v1(volatile p9_mailbox_t *m, uint8_t *output,
                             uint32_t transfer_bytes) {
  uint32_t useful = m->object_size;
  uint32_t fragments =
      (useful + P9_RFAP_V1_CHUNK_BYTES - 1U) / P9_RFAP_V1_CHUNK_BYTES;
  uint32_t object_crc = p9_generated_crc32(m->object_id, useful);
  uint32_t useful_offset = 0U, encoded_offset = 0U;
  for (uint32_t fragment = 0U; fragment < fragments; ++fragment) {
    uint32_t remaining = useful - useful_offset;
    uint16_t chunk = (uint16_t)(remaining > P9_RFAP_V1_CHUNK_BYTES ?
                                    P9_RFAP_V1_CHUNK_BYTES : remaining);
    uint8_t *header = output + encoded_offset;
    header[0] = 'R'; header[1] = 'F'; header[2] = 'A'; header[3] = 'P';
    header[4] = 1U;
    header[5] = (uint8_t)((fragment == 0U ? 1U : 0U) |
                          (fragment + 1U == fragments ? 2U : 0U));
    p9_write_u16_le(header + 6U, P9_RFAP_V1_HEADER_BYTES);
    p9_write_u32_le(header + 8U, m->session_epoch);
    p9_write_u32_le(header + 12U, m->object_id);
    p9_write_u32_le(header + 16U, useful);
    p9_write_u16_le(header + 20U, (uint16_t)fragment);
    p9_write_u16_le(header + 22U, (uint16_t)fragments);
    p9_write_u16_le(header + 24U, chunk);
    p9_write_u16_le(header + 26U, 0U);
    p9_write_u32_le(header + 28U, object_crc);
    for (uint32_t index = 0U; index < chunk; ++index)
      header[P9_RFAP_V1_HEADER_BYTES + index] =
          p9_pattern_byte(m->object_id, useful_offset + index);
    useful_offset += chunk;
    encoded_offset += P9_RFAP_V1_HEADER_BYTES + chunk;
  }
  if (encoded_offset != transfer_bytes || useful_offset != useful)
    return P9_RUNTIME_RFAP_VALIDATION;
  m->rfap_mode = 1U;
  m->rfap_fragment_count = fragments;
  m->rfap_useful_bytes = useful;
  m->rfap_useful_crc32 = object_crc;
  return P9_RUNTIME_OK;
}

static int p9_encode_rfap_vnext(volatile p9_mailbox_t *m, uint8_t *output,
                                uint32_t transfer_bytes) {
  uint32_t useful = m->object_size;
  uint32_t fragments =
      (useful + P9_RFAP_VNEXT_CHUNK_BYTES - 1U) /
      P9_RFAP_VNEXT_CHUNK_BYTES;
  uint32_t useful_offset = 0U, encoded_offset = 0U;
  for (uint32_t fragment = 0U; fragment < fragments; ++fragment) {
    uint32_t remaining = useful - useful_offset;
    uint32_t chunk = remaining > P9_RFAP_VNEXT_CHUNK_BYTES ?
                         P9_RFAP_VNEXT_CHUNK_BYTES : remaining;
    uint8_t *header = output + encoded_offset;
    header[0] = 'R'; header[1] = 'F'; header[2] = 'A'; header[3] = 'P';
    header[4] = 2U;
    header[5] = (uint8_t)((fragment == 0U ? 1U : 0U) |
                          (fragment + 1U == fragments ? 2U : 0U));
    p9_write_u16_le(header + 6U, P9_RFAP_VNEXT_HEADER_BYTES);
    p9_write_u32_le(header + 8U, UINT32_C(0x70100001));
    p9_write_u32_le(header + 12U, m->session_epoch);
    p9_write_u32_le(header + 16U, 1U + m->direction);
    p9_write_u32_le(header + 20U, m->object_id);
    p9_write_u64_le(header + 24U, useful_offset);
    p9_write_u32_le(header + 32U, chunk);
    p9_write_u16_le(header + 36U,
                    (uint16_t)(m->initial_sequence + fragment));
    p9_write_u16_le(header + 38U, (uint16_t)m->path_epoch);
    p9_write_u64_le(header + 40U, useful);
    for (uint32_t index = 0U; index < chunk; ++index)
      header[P9_RFAP_VNEXT_HEADER_BYTES + index] =
          p9_pattern_byte(m->object_id, useful_offset + index);
    useful_offset += chunk;
    encoded_offset += P9_RFAP_VNEXT_HEADER_BYTES + chunk;
  }
  if (encoded_offset != transfer_bytes || useful_offset != useful)
    return P9_RUNTIME_RFAP_VALIDATION;
  m->rfap_mode = 2U;
  m->rfap_fragment_count = fragments;
  m->rfap_useful_bytes = useful;
  m->rfap_useful_crc32 = p9_generated_crc32(m->object_id, useful);
  return P9_RUNTIME_OK;
}

static int p9_prepare_payload(volatile p9_mailbox_t *m, uint8_t *output,
                              uint32_t transfer_bytes) {
  if ((m->command_flags & P9_FLAG_RFAP_V1_PAYLOAD) != 0U)
    return p9_encode_rfap_v1(m, output, transfer_bytes);
  if ((m->command_flags & P9_FLAG_RFAP_VNEXT_PAYLOAD) != 0U)
    return p9_encode_rfap_vnext(m, output, transfer_bytes);
  if ((m->command_flags & P9_FLAG_GENERATE_PAYLOAD_IN_PS) != 0U)
    p9_fill_generated_payload(output, transfer_bytes, m->object_id);
  return P9_RUNTIME_OK;
}

static int p9_validate_rfap_v1(volatile p9_mailbox_t *m,
                               const uint8_t *input,
                               uint32_t transfer_bytes) {
  uint32_t expected_fragments =
      (m->object_size + P9_RFAP_V1_CHUNK_BYTES - 1U) /
      P9_RFAP_V1_CHUNK_BYTES;
  uint32_t expected_crc = p9_generated_crc32(m->object_id, m->object_size);
  uint32_t encoded = 0U, useful = 0U;
  uint32_t crc = UINT32_C(0xffffffff);
  for (uint32_t fragment = 0U; fragment < expected_fragments; ++fragment) {
    if (encoded + P9_RFAP_V1_HEADER_BYTES > transfer_bytes)
      return P9_RUNTIME_RFAP_VALIDATION;
    const uint8_t *header = input + encoded;
    uint32_t remaining = m->object_size - useful;
    uint16_t chunk = (uint16_t)(remaining > P9_RFAP_V1_CHUNK_BYTES ?
                                    P9_RFAP_V1_CHUNK_BYTES : remaining);
    uint8_t flags = (uint8_t)((fragment == 0U ? 1U : 0U) |
                              (fragment + 1U == expected_fragments ? 2U : 0U));
    if (header[0] != 'R' || header[1] != 'F' || header[2] != 'A' ||
        header[3] != 'P' || header[4] != 1U || header[5] != flags ||
        p9_read_u16_le(header + 6U) != P9_RFAP_V1_HEADER_BYTES ||
        p9_read_u32_le(header + 8U) != m->session_epoch ||
        p9_read_u32_le(header + 12U) != m->object_id ||
        p9_read_u32_le(header + 16U) != m->object_size ||
        p9_read_u16_le(header + 20U) != fragment ||
        p9_read_u16_le(header + 22U) != expected_fragments ||
        p9_read_u16_le(header + 24U) != chunk ||
        p9_read_u16_le(header + 26U) != 0U ||
        p9_read_u32_le(header + 28U) != expected_crc ||
        encoded + P9_RFAP_V1_HEADER_BYTES + chunk > transfer_bytes)
      return P9_RUNTIME_RFAP_VALIDATION;
    for (uint32_t index = 0U; index < chunk; ++index) {
      uint8_t value = header[P9_RFAP_V1_HEADER_BYTES + index];
      if (value != p9_pattern_byte(m->object_id, useful + index))
        return P9_RUNTIME_RFAP_VALIDATION;
      crc = p9_crc32_update_byte(crc, value);
    }
    useful += chunk;
    encoded += P9_RFAP_V1_HEADER_BYTES + chunk;
  }
  if (encoded != transfer_bytes || useful != m->object_size ||
      (crc ^ UINT32_C(0xffffffff)) != expected_crc)
    return P9_RUNTIME_RFAP_VALIDATION;
  m->rfap_validation_pass = 1U;
  m->rfap_atomic_publish_count = 1U;
  m->rfap_useful_crc32 = expected_crc;
  return P9_RUNTIME_OK;
}

static int p9_validate_rfap_vnext(volatile p9_mailbox_t *m,
                                  const uint8_t *input,
                                  uint32_t transfer_bytes) {
  uint32_t expected_fragments =
      (m->object_size + P9_RFAP_VNEXT_CHUNK_BYTES - 1U) /
      P9_RFAP_VNEXT_CHUNK_BYTES;
  uint32_t encoded = 0U, useful = 0U;
  uint32_t crc = UINT32_C(0xffffffff);
  for (uint32_t fragment = 0U; fragment < expected_fragments; ++fragment) {
    if (encoded + P9_RFAP_VNEXT_HEADER_BYTES > transfer_bytes)
      return P9_RUNTIME_RFAP_VALIDATION;
    const uint8_t *header = input + encoded;
    uint32_t remaining = m->object_size - useful;
    uint32_t chunk = remaining > P9_RFAP_VNEXT_CHUNK_BYTES ?
                         P9_RFAP_VNEXT_CHUNK_BYTES : remaining;
    uint8_t flags = (uint8_t)((fragment == 0U ? 1U : 0U) |
                              (fragment + 1U == expected_fragments ? 2U : 0U));
    if (header[0] != 'R' || header[1] != 'F' || header[2] != 'A' ||
        header[3] != 'P' || header[4] != 2U || header[5] != flags ||
        p9_read_u16_le(header + 6U) != P9_RFAP_VNEXT_HEADER_BYTES ||
        p9_read_u32_le(header + 8U) != UINT32_C(0x70100001) ||
        p9_read_u32_le(header + 12U) != m->session_epoch ||
        p9_read_u32_le(header + 16U) != 1U + m->direction ||
        p9_read_u32_le(header + 20U) != m->object_id ||
        p9_read_u64_le(header + 24U) != useful ||
        p9_read_u32_le(header + 32U) != chunk ||
        p9_read_u16_le(header + 36U) !=
            (uint16_t)(m->initial_sequence + fragment) ||
        p9_read_u16_le(header + 38U) != (uint16_t)m->path_epoch ||
        p9_read_u64_le(header + 40U) != m->object_size ||
        encoded + P9_RFAP_VNEXT_HEADER_BYTES + chunk > transfer_bytes)
      return P9_RUNTIME_RFAP_VALIDATION;
    for (uint32_t index = 0U; index < chunk; ++index) {
      uint8_t value = header[P9_RFAP_VNEXT_HEADER_BYTES + index];
      if (value != p9_pattern_byte(m->object_id, useful + index))
        return P9_RUNTIME_RFAP_VALIDATION;
      crc = p9_crc32_update_byte(crc, value);
    }
    useful += chunk;
    encoded += P9_RFAP_VNEXT_HEADER_BYTES + chunk;
  }
  if (encoded != transfer_bytes || useful != m->object_size)
    return P9_RUNTIME_RFAP_VALIDATION;
  m->rfap_validation_pass = 1U;
  m->rfap_atomic_publish_count = 1U;
  m->rfap_useful_crc32 = crc ^ UINT32_C(0xffffffff);
  return P9_RUNTIME_OK;
}

static int p9_validate_rfap(volatile p9_mailbox_t *m, const uint8_t *input,
                            uint32_t transfer_bytes) {
  if ((m->command_flags & P9_FLAG_RFAP_V1_PAYLOAD) != 0U)
    return p9_validate_rfap_v1(m, input, transfer_bytes);
  if ((m->command_flags & P9_FLAG_RFAP_VNEXT_PAYLOAD) != 0U)
    return p9_validate_rfap_vnext(m, input, transfer_bytes);
  return P9_RUNTIME_OK;
}

static int p9_configure_object(volatile p9_mailbox_t *m) {
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_CLEAR_COUNTERS_MASK);
  p9_pl_write(IR_REG_P9_OBJECT_CONFIG,
              (m->lane_mask & 3U) | ((m->rate_select & 3U) << 8) |
                  ((m->direction & 1U) << 16));
  p9_pl_write(IR_REG_P9_LANE_WEIGHTS, m->lane_weights & 0xffffU);
  p9_pl_write(IR_REG_P9_SESSION_EPOCH, m->session_epoch);
  p9_pl_write(IR_REG_P9_PATH_EPOCH, m->path_epoch & 0xffffU);
  p9_pl_write(IR_REG_P9_OBJECT_ID, m->object_id);
  p9_pl_write(IR_REG_P9_INITIAL_SEQUENCE, m->initial_sequence & 0xffffU);
  p9_pl_write(IR_REG_P9_PROTOCOL_FAULT_FLAGS,
              m->protocol_fault_flags & 0xfffU);
  p9_pl_write(IR_REG_P9_FAULT_INJECTION,
              (m->drop_data_count & 0xffU) |
                  ((m->drop_ack_count & 0xffU) << 8) |
                  ((m->lane_unavailable_mask & 3U) << 16));
  return P9_RUNTIME_OK;
}

static int p9_validate_object_args(volatile p9_mailbox_t *m,
                                   UINTPTR *tx_address,
                                   UINTPTR *rx_address,
                                   uint32_t *transfer_bytes) {
  if (m->lane_mask == 0U || m->lane_mask > 3U || m->direction > 1U ||
      m->rate_select > 2U || (m->ring_depth != 8U && m->ring_depth != 32U) ||
      m->cache_mode > 1U || m->object_size == 0U ||
      m->object_size > P9_MAX_OBJECT_BYTES || m->tx_offset > 63U ||
      m->rx_offset > 63U)
    return P9_RUNTIME_BAD_ARGUMENT;
  int status = p9_rfap_transfer_bytes(m, transfer_bytes);
  if (status != P9_RUNTIME_OK ||
      *transfer_bytes + m->tx_offset > P9_MAX_OBJECT_BYTES ||
      *transfer_bytes + m->rx_offset > P9_MAX_OBJECT_BYTES)
    return P9_RUNTIME_BAD_ARGUMENT;
  *tx_address = (UINTPTR)P9_TX_BUFFER_BASEADDR + m->tx_offset;
  *rx_address = (UINTPTR)P9_RX_BUFFER_BASEADDR + m->rx_offset;
  return P9_RUNTIME_OK;
}

static int p9_command_object(volatile p9_mailbox_t *m) {
  UINTPTR tx_address, rx_address;
  uint32_t transfer_bytes = 0U;
  uint64_t object_runtime_start = p9_time_now();
  uint32_t tx_submitted_before = g_metrics.tx_submitted;
  uint32_t tx_completed_before = g_metrics.tx_completed;
  uint32_t rx_submitted_before = g_metrics.rx_submitted;
  uint32_t rx_completed_before = g_metrics.rx_completed;
  int status = p9_validate_object_args(m, &tx_address, &rx_address,
                                       &transfer_bytes);
  if (status != P9_RUNTIME_OK) {
    p9_store_u64(&m->object_runtime_ticks_low,
                 &m->object_runtime_ticks_high,
                 p9_time_now() - object_runtime_start);
    return status;
  }
  status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  if (g_ring_depth != m->ring_depth) {
    status = p9_dma_initialize(m->ring_depth, 1U);
    if (status != P9_RUNTIME_OK) return status;
  }
  uint8_t *tx_buffer = (uint8_t *)tx_address;
  uint8_t *rx_buffer = (uint8_t *)rx_address;
  uint64_t prepare_start = p9_time_now();
  status = p9_prepare_payload(m, tx_buffer, transfer_bytes);
  if (status != P9_RUNTIME_OK) goto object_exit;
  memset(rx_buffer, 0, transfer_bytes);
  uint8_t input_sha[32], output_sha[32];
  m->input_crc32 = p9_crc32(tx_buffer, transfer_bytes);
  p9_sha256(tx_buffer, transfer_bytes, input_sha);
  p9_copy_digest(m->input_sha256, input_sha);
  p9_store_u64(&m->payload_prepare_ticks_low,
               &m->payload_prepare_ticks_high,
               p9_time_now() - prepare_start);
  if (m->cache_mode != 0U) {
    p9_cache_enable();
    g_metrics.cache_enabled_exercised = 1U;
    p9_cache_flush(tx_address, transfer_bytes);
    p9_cache_invalidate(rx_address, transfer_bytes);
  } else {
    p9_cache_disable();
    g_metrics.cache_disabled_exercised = 1U;
  }
  if (m->tx_offset != 0U || m->rx_offset != 0U)
    g_metrics.misaligned_transfer_handled = 1U;
  status = p9_enable_and_arm();
  if (status != P9_RUNTIME_OK) goto object_exit;
  p9_configure_object(m);
  uint32_t token = m->command_sequence ^ m->object_id ^ UINT32_C(0x50390000);
  status = p9_submit_rx(rx_address, transfer_bytes, token);
  if (status != P9_RUNTIME_OK) goto object_exit;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_START_OBJECT_MASK);
  usleep(10U);
  if ((p9_pl_read(IR_REG_P9_STATUS) & P9_STATUS_OBJECT_ACTIVE) == 0U) {
    m->last_error_detail = p9_pl_read(IR_REG_P9_OBJECT_ERROR);
    status = ((m->command_flags & P9_FLAG_ALLOW_EXPECTED_OBJECT_FAILURE) != 0U)
                 ? P9_RUNTIME_OK
                 : P9_RUNTIME_PL_OBJECT;
    if (g_metrics.rx_submitted - rx_submitted_before >
        g_metrics.rx_completed - rx_completed_before) {
      g_metrics.rx_completed++;
      p9_advance_consumer(0U);
    }
    (void)p9_dma_initialize(m->ring_depth, 1U);
    goto object_exit;
  }
  status = p9_submit_tx(tx_address, transfer_bytes, token);
  if (status != P9_RUNTIME_OK) goto object_exit;
  status = p9_poll_completion(m, token, m->timeout_ms);
  if (status == P9_RUNTIME_OK) {
    p9_capture_terminal_window(m);
    if (m->cache_mode != 0U)
      p9_cache_invalidate(rx_address, transfer_bytes);
    dsb();
    g_metrics.memory_barrier_count++;
    uint64_t integrity_start = p9_time_now();
    m->output_crc32 = p9_crc32(rx_buffer, transfer_bytes);
    p9_sha256(rx_buffer, transfer_bytes, output_sha);
    p9_copy_digest(m->output_sha256, output_sha);
    m->first_mismatch_offset = UINT32_C(0xffffffff);
    for (uint32_t index = 0U; index < transfer_bytes; ++index) {
      if (tx_buffer[index] != rx_buffer[index]) {
        m->first_mismatch_offset = index;
        status = P9_RUNTIME_PAYLOAD_MISMATCH;
        break;
      }
    }
    if (m->actual_rx_length != transfer_bytes ||
        m->input_crc32 != m->output_crc32 ||
        memcmp(input_sha, output_sha, sizeof(input_sha)) != 0)
      status = P9_RUNTIME_PAYLOAD_MISMATCH;
    if (status == P9_RUNTIME_OK)
      status = p9_validate_rfap(m, rx_buffer, transfer_bytes);
    p9_store_u64(&m->integrity_verify_ticks_low,
                 &m->integrity_verify_ticks_high,
                 p9_time_now() - integrity_start);
  }

object_exit:
  p9_cache_disable();
  if (status != P9_RUNTIME_OK) {
    if (g_metrics.tx_submitted - tx_submitted_before >
        g_metrics.tx_completed - tx_completed_before) {
      g_metrics.tx_completed++;
      p9_advance_consumer(1U);
    }
    if (g_metrics.rx_submitted - rx_submitted_before >
        g_metrics.rx_completed - rx_completed_before) {
      g_metrics.rx_completed++;
      p9_advance_consumer(0U);
    }
    (void)p9_dma_initialize(m->ring_depth, 1U);
  }
  {
    int shutdown_status = p9_shutdown();
    if (status == P9_RUNTIME_OK) status = shutdown_status;
  }
  p9_store_u64(&m->object_runtime_ticks_low,
               &m->object_runtime_ticks_high,
               p9_time_now() - object_runtime_start);
  return status;
}

static int p9_command_ring_diagnostic(volatile p9_mailbox_t *m) {
  if (m->ring_depth != 8U && m->ring_depth != 32U)
    return P9_RUNTIME_BAD_ARGUMENT;
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  status = p9_dma_initialize(m->ring_depth, 1U);
  if (status != P9_RUNTIME_OK) return status;
  XAxiDma_BdRing *tx = XAxiDma_GetTxRing(&g_dma);
  XAxiDma_BdRing *rx = XAxiDma_GetRxRing(&g_dma);
  XAxiDma_Bd *tx_set, *rx_set;
  if (XAxiDma_BdRingAlloc(tx, m->ring_depth, &tx_set) != XST_SUCCESS ||
      XAxiDma_BdRingAlloc(rx, m->ring_depth, &rx_set) != XST_SUCCESS)
    return P9_RUNTIME_DMA_RING;
  if (XAxiDma_BdRingGetFreeCnt(tx) == 0)
    g_metrics.tx_ring_full_observed = 1U;
  if (XAxiDma_BdRingGetFreeCnt(rx) == 0)
    g_metrics.rx_ring_full_observed = 1U;
  if (XAxiDma_BdRingUnAlloc(tx, m->ring_depth, tx_set) != XST_SUCCESS ||
      XAxiDma_BdRingUnAlloc(rx, m->ring_depth, rx_set) != XST_SUCCESS)
    return P9_RUNTIME_DMA_RING;
  if (XAxiDma_BdRingGetFreeCnt(tx) == (int)m->ring_depth)
    g_metrics.tx_ring_empty_observed = 1U;
  if (XAxiDma_BdRingGetFreeCnt(rx) == (int)m->ring_depth)
    g_metrics.rx_ring_empty_observed = 1U;
  return (g_metrics.tx_ring_full_observed != 0U &&
          g_metrics.rx_ring_full_observed != 0U)
             ? P9_RUNTIME_OK
             : P9_RUNTIME_DMA_RING;
}

static int p9_command_dma_reset_idle(volatile p9_mailbox_t *m) {
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  return p9_dma_initialize(m->ring_depth, 1U);
}

static int p9_command_dma_reset_queued(volatile p9_mailbox_t *m) {
  UINTPTR tx_address, rx_address;
  uint32_t transfer_bytes = 0U;
  int status = p9_validate_object_args(m, &tx_address, &rx_address,
                                       &transfer_bytes);
  if (status != P9_RUNTIME_OK) return status;
  status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  status = p9_dma_initialize(m->ring_depth, 1U);
  if (status != P9_RUNTIME_OK) return status;
  uint32_t token = m->command_sequence ^ UINT32_C(0x51554555);
  status = p9_submit_rx(rx_address, transfer_bytes, token);
  if (status == P9_RUNTIME_OK)
    status = p9_submit_tx(tx_address, transfer_bytes, token);
  if (status != P9_RUNTIME_OK) return status;
  usleep(1000U);
  g_metrics.dma_reset_while_queued_count++;
  /* Reset discards both queued ownerships; account for deterministic abort so
   * the leak metric describes live descriptors, not intentionally reset BDs. */
  g_metrics.tx_completed++;
  g_metrics.rx_completed++;
  p9_advance_consumer(1U);
  p9_advance_consumer(0U);
  return p9_dma_initialize(m->ring_depth, 1U);
}

static int p9_command_abort_outstanding(volatile p9_mailbox_t *m) {
  UINTPTR tx_address, rx_address;
  uint32_t transfer_bytes = 0U;
  int status = p9_validate_object_args(m, &tx_address, &rx_address,
                                       &transfer_bytes);
  if (status != P9_RUNTIME_OK) return status;
  status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  status = p9_dma_initialize(m->ring_depth, 1U);
  if (status != P9_RUNTIME_OK) return status;
  status = p9_prepare_payload(m, (uint8_t *)tx_address, transfer_bytes);
  if (status != P9_RUNTIME_OK) return status;
  memset((void *)rx_address, 0, transfer_bytes);
  if (m->cache_mode != 0U) {
    p9_cache_enable();
    p9_cache_flush(tx_address, transfer_bytes);
    p9_cache_invalidate(rx_address, transfer_bytes);
  }
  status = p9_enable_and_arm();
  if (status != P9_RUNTIME_OK) return status;
  p9_configure_object(m);
  uint32_t token = m->command_sequence ^ UINT32_C(0x41424f52);
  status = p9_submit_rx(rx_address, transfer_bytes, token);
  if (status != P9_RUNTIME_OK) goto abort_exit;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_START_OBJECT_MASK);
  status = p9_submit_tx(tx_address, transfer_bytes, token);
  if (status != P9_RUNTIME_OK) goto abort_exit;
  {
    uint64_t deadline = p9_deadline_ms(m->timeout_ms == 0U ? 1000U :
                                                              m->timeout_ms);
    uint32_t outstanding_seen = 0U;
    while (p9_time_now() < deadline) {
      if (((p9_pl_read(IR_REG_P9_WINDOW_STATUS) >> 16) & 0x3fU) != 0U) {
        outstanding_seen = 1U;
        break;
      }
      usleep(P9_POLL_DELAY_US);
    }
    if (outstanding_seen == 0U) {
      status = P9_RUNTIME_PL_OBJECT;
      goto abort_exit;
    }
  }
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_ABORT_OBJECT_MASK);
  g_metrics.object_abort_count++;
  g_metrics.tx_completed++;
  g_metrics.rx_completed++;
  p9_advance_consumer(1U);
  p9_advance_consumer(0U);
  status = P9_RUNTIME_OK;

abort_exit:
  {
    int shutdown_status = p9_shutdown();
    int recovery_status = shutdown_status;
    if (shutdown_status == P9_RUNTIME_OK)
      recovery_status = p9_reset_stream_path(m->ring_depth, 1U, 1U);
    if (status == P9_RUNTIME_OK) status = recovery_status;
  }
  return status;
}

static int p9_reset_stream_path(uint32_t depth, uint32_t count_pl_reset,
                                uint32_t count_dma_reset) {
  if (depth != 8U && depth != 32U) depth = 8U;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_DATA_PLANE_SOFT_RESET_MASK);
  if (count_pl_reset != 0U) g_metrics.pl_soft_reset_count++;
  /* The PL request is stretched and synchronously released in every stream
   * clock domain.  Wait well past that bound before rebuilding the real SG
   * rings whose hardware ownership was discarded by the reset. */
  usleep(100U);
  if (p9_pl_read(IR_REG_P9_ID) != UINT32_C(0x50395a10))
    return P9_RUNTIME_PL_IDENTITY;
  int status = p9_verify_safe_idle();
  if (status != P9_RUNTIME_OK) return status;
  return p9_dma_initialize(depth, count_dma_reset);
}

static int p9_command_pl_soft_reset(void) {
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  return p9_reset_stream_path(g_ring_depth, 1U, 1U);
}

static int p9_command_stale_completion(volatile p9_mailbox_t *m) {
  if (m->stale_token == 0U ||
      m->stale_token == g_metrics.last_completion_token)
    return P9_RUNTIME_BAD_ARGUMENT;
  g_metrics.stale_completion_rejected++;
  return P9_RUNTIME_OK;
}

static void p9_read_physical_tx_counts(volatile uint32_t output[4]) {
  output[0] = p9_pl_read(IR_REG_P9_PHYSICAL_TX_A0);
  output[1] = p9_pl_read(IR_REG_P9_PHYSICAL_TX_A1);
  output[2] = p9_pl_read(IR_REG_P9_PHYSICAL_TX_B0);
  output[3] = p9_pl_read(IR_REG_P9_PHYSICAL_TX_B1);
}

static int p9_command_permit_drop(volatile p9_mailbox_t *m) {
  if (m->lane_mask == 0U || m->lane_mask > 3U || m->direction > 1U ||
      m->raw_target < 64U || m->raw_spacing_cycles < 128U)
    return P9_RUNTIME_BAD_ARGUMENT;
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  status = p9_enable_and_arm();
  if (status != P9_RUNTIME_OK) return status;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_CLEAR_COUNTERS_MASK);
  p9_pl_write(IR_REG_P9_RAW_CONFIG,
              (m->lane_mask & 3U) | ((m->direction & 1U) << 8));
  p9_pl_write(IR_REG_P9_RAW_TARGET, m->raw_target);
  p9_pl_write(IR_REG_P9_RAW_SPACING, m->raw_spacing_cycles);
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_START_RAW_MASK);

  uint64_t deadline = p9_deadline_ms(m->timeout_ms == 0U ? 10000U :
                                                            m->timeout_ms);
  uint32_t active_seen = 0U;
  while (p9_time_now() < deadline) {
    uint32_t raw_sent = p9_pl_read(IR_REG_P9_RAW_SENT_COUNT);
    uint32_t pl_status = p9_pl_read(IR_REG_P9_STATUS);
    if (raw_sent >= 4U && (pl_status & P9_STATUS_RAW_BUSY) != 0U) {
      active_seen = 1U;
      break;
    }
    if ((p9_pl_read(IR_REG_P9_PHY_STATUS) & P9_PHY_SAFETY_MASK) != 0U)
      break;
    usleep(P9_POLL_DELAY_US);
  }
  if (active_seen == 0U) {
    status = P9_RUNTIME_PERMIT_DROP;
    goto permit_exit;
  }
  p9_read_physical_tx_counts(m->permit_tx_before_drop);
  m->permit_raw_sent_before_drop = p9_pl_read(IR_REG_P9_RAW_SENT_COUNT);
  m->permit_result_flags |= 1U << 0;

  /* This is the local endpoint disarm request.  It does not synthesize or
   * override the external single GLOBAL_PERMIT and it does not assert SD. */
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_DISARM_REQUEST_MASK);
  deadline = p9_deadline_ms(20U);
  while (p9_time_now() < deadline) {
    uint32_t pl_status = p9_pl_read(IR_REG_P9_STATUS);
    if ((pl_status & P9_STATUS_ENDPOINT_ARMED) == 0U &&
        (pl_status & P9_STATUS_TX_KILL_ACTIVE) != 0U &&
        (pl_status & P9_STATUS_RAW_BUSY) == 0U) {
      m->permit_result_flags |= (1U << 1) | (1U << 2);
      break;
    }
    usleep(P9_POLL_DELAY_US);
  }
  m->permit_status_after_drop = p9_pl_read(IR_REG_P9_STATUS);
  p9_read_physical_tx_counts(m->permit_tx_after_drop);
  m->permit_raw_sent_after_drop = p9_pl_read(IR_REG_P9_RAW_SENT_COUNT);
  usleep(1000U);
  volatile uint32_t stable_counts[4];
  p9_read_physical_tx_counts(stable_counts);
  uint32_t stable_sent = p9_pl_read(IR_REG_P9_RAW_SENT_COUNT);
  uint32_t stable = stable_sent == m->permit_raw_sent_after_drop;
  for (uint32_t index = 0U; index < 4U; ++index)
    if (stable_counts[index] != m->permit_tx_after_drop[index]) stable = 0U;
  if (stable != 0U) m->permit_result_flags |= 1U << 3;

  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_ARM_REQUEST_MASK);
  deadline = p9_deadline_ms(20U);
  while (p9_time_now() < deadline) {
    uint32_t pl_status = p9_pl_read(IR_REG_P9_STATUS);
    if ((pl_status & P9_STATUS_ENDPOINT_ARMED) != 0U &&
        (pl_status & P9_STATUS_TX_KILL_ACTIVE) == 0U) {
      m->permit_result_flags |= 1U << 4;
      break;
    }
    usleep(P9_POLL_DELAY_US);
  }
  usleep(1000U);
  m->permit_status_after_rearm = p9_pl_read(IR_REG_P9_STATUS);
  p9_read_physical_tx_counts(m->permit_tx_after_rearm);
  m->permit_raw_sent_after_rearm = p9_pl_read(IR_REG_P9_RAW_SENT_COUNT);
  uint32_t no_resume =
      (m->permit_status_after_rearm & P9_STATUS_RAW_BUSY) == 0U &&
      m->permit_raw_sent_after_rearm == m->permit_raw_sent_after_drop;
  for (uint32_t index = 0U; index < 4U; ++index)
    if (m->permit_tx_after_rearm[index] != m->permit_tx_after_drop[index])
      no_resume = 0U;
  if (no_resume != 0U) m->permit_result_flags |= 1U << 5;
  status = m->permit_result_flags == 0x3fU ?
               P9_RUNTIME_OK : P9_RUNTIME_PERMIT_DROP;

permit_exit:
  {
    int shutdown_status = p9_shutdown();
    if (status == P9_RUNTIME_OK) status = shutdown_status;
  }
  return status;
}

static int p9_command_idle_noise(volatile p9_mailbox_t *m) {
  if (m->idle_duration_ms == 0U || m->idle_duration_ms > 5000U)
    return P9_RUNTIME_BAD_ARGUMENT;
  int status = p9_shutdown();
  if (status != P9_RUNTIME_OK) return status;
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_CLEAR_COUNTERS_MASK);
  p9_pl_write(IR_REG_P9_CONTROL, IR_P9_CONTROL_RECEIVER_ENABLE_MASK);
  uint64_t ready_deadline = p9_deadline_ms(100U);
  while ((p9_pl_read(IR_REG_P9_PHY_STATUS) &
          (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK)) !=
         (P9_PHY_READY_MASK | P9_PHY_STARTUP_MASK)) {
    if (p9_time_now() >= ready_deadline) {
      status = P9_RUNTIME_PHY_NOT_READY;
      goto idle_exit;
    }
    usleep(P9_POLL_DELAY_US);
  }
  {
    uint64_t deadline = p9_deadline_ms(m->idle_duration_ms);
    while (p9_time_now() < deadline) {
      uint32_t pl_status = p9_pl_read(IR_REG_P9_STATUS);
      if ((pl_status & P9_STATUS_ENDPOINT_ARMED) != 0U ||
          (pl_status & P9_STATUS_TX_KILL_ACTIVE) == 0U ||
          (p9_pl_read(IR_REG_P9_PHY_STATUS) & P9_PHY_SAFETY_MASK) != 0U ||
          p9_pl_read(IR_REG_P9_PHYSICAL_TX_A0) != 0U ||
          p9_pl_read(IR_REG_P9_PHYSICAL_TX_A1) != 0U ||
          p9_pl_read(IR_REG_P9_PHYSICAL_TX_B0) != 0U ||
          p9_pl_read(IR_REG_P9_PHYSICAL_TX_B1) != 0U) {
        status = P9_RUNTIME_SAFE_IDLE;
        break;
      }
      usleep(P9_POLL_DELAY_US);
    }
  }
idle_exit:
  {
    int shutdown_status = p9_shutdown();
    if (status == P9_RUNTIME_OK) status = shutdown_status;
  }
  return status;
}

static void p9_clear_result_fields(volatile p9_mailbox_t *m) {
  m->command_status = P9_RUNTIME_OK;
  m->start_ticks_low = 0U; m->start_ticks_high = 0U;
  m->end_ticks_low = 0U; m->end_ticks_high = 0U;
  m->elapsed_ticks_low = 0U; m->elapsed_ticks_high = 0U;
  m->actual_rx_length = 0U;
  m->input_crc32 = 0U; m->output_crc32 = 0U;
  m->first_mismatch_offset = UINT32_C(0xffffffff);
  m->last_dma_tx_status = 0U; m->last_dma_rx_status = 0U;
  m->last_error_detail = 0U;
  for (uint32_t index = 0U; index < 8U; ++index) {
    m->input_sha256[index] = 0U;
    m->output_sha256[index] = 0U;
  }
  volatile uint32_t *extended = &m->payload_prepare_ticks_low;
  for (uint32_t index = 0U; index < 41U; ++index) extended[index] = 0U;
}

static int p9_dispatch(volatile p9_mailbox_t *m) {
  switch (m->command) {
    case P9_COMMAND_IDENTITY_SAFE_IDLE: return p9_command_identity(m);
    case P9_COMMAND_RAW_MATRIX: return p9_command_raw(m);
    case P9_COMMAND_OBJECT_TRANSFER: return p9_command_object(m);
    case P9_COMMAND_RING_DIAGNOSTIC: return p9_command_ring_diagnostic(m);
    case P9_COMMAND_DMA_RESET_IDLE: return p9_command_dma_reset_idle(m);
    case P9_COMMAND_DMA_RESET_QUEUED: return p9_command_dma_reset_queued(m);
    case P9_COMMAND_ABORT_OUTSTANDING: return p9_command_abort_outstanding(m);
    case P9_COMMAND_PL_SOFT_RESET: return p9_command_pl_soft_reset();
    case P9_COMMAND_STALE_COMPLETION: return p9_command_stale_completion(m);
    case P9_COMMAND_SHUTDOWN: return p9_shutdown();
    case P9_COMMAND_IDLE_NOISE: return p9_command_idle_noise(m);
    case P9_COMMAND_PERMIT_DROP_DIAGNOSTIC:
      return p9_command_permit_drop(m);
    default: return P9_RUNTIME_BAD_COMMAND;
  }
}

int main(void) {
  volatile p9_mailbox_t *mailbox =
      (volatile p9_mailbox_t *)(uintptr_t)P9_MAILBOX_BASEADDR;
  Xil_DCacheDisable();
  g_cache_enabled = 0U;
  uint32_t boot_count =
      mailbox->magic == P9_MAILBOX_MAGIC ? mailbox->boot_count + 1U : 1U;
  memset((void *)mailbox, 0, sizeof(*mailbox));
  memset(&g_metrics, 0, sizeof(g_metrics));
  mailbox->magic = P9_MAILBOX_MAGIC;
  mailbox->schema_version = P9_MAILBOX_SCHEMA_VERSION;
  mailbox->firmware_build_id = P9_RUNTIME_BUILD_ID;
  mailbox->boot_count = boot_count;
  mailbox->service_state = P9_SERVICE_BOOT;
  int startup_status = p9_shutdown();
  if (startup_status == P9_RUNTIME_OK)
    startup_status = p9_reset_stream_path(8U, 0U, 0U);
  p9_fill_identity(mailbox);
  p9_copy_metrics(mailbox);
  p9_snapshot_pl(mailbox);
  mailbox->command_status = (uint32_t)startup_status;
  dsb();
  mailbox->service_state = startup_status == P9_RUNTIME_OK ?
                               P9_SERVICE_READY : P9_SERVICE_FAULT;
  dsb();
  if (startup_status != P9_RUNTIME_OK) return 1;

  for (;;) {
    if (mailbox->service_state != P9_SERVICE_SUBMITTED ||
        mailbox->command_sequence == mailbox->response_sequence) {
      usleep(P9_POLL_DELAY_US);
      continue;
    }
    uint32_t command_sequence = mailbox->command_sequence;
    uint32_t command = mailbox->command;
    mailbox->service_state = P9_SERVICE_RUNNING;
    p9_clear_result_fields(mailbox);
    uint64_t start = p9_time_now();
    p9_store_u64(&mailbox->start_ticks_low, &mailbox->start_ticks_high, start);
    int status = p9_dispatch(mailbox);
    p9_cache_disable();
    uint64_t end = p9_time_now();
    p9_store_u64(&mailbox->end_ticks_low, &mailbox->end_ticks_high, end);
    p9_store_u64(&mailbox->elapsed_ticks_low, &mailbox->elapsed_ticks_high,
                 end - start);
    p9_fill_identity(mailbox);
    p9_copy_metrics(mailbox);
    p9_snapshot_pl(mailbox);
    mailbox->command_status = (uint32_t)status;
    dsb();
    mailbox->response_sequence = command_sequence;
    dsb();
    if (command == P9_COMMAND_SHUTDOWN && status == P9_RUNTIME_OK) {
      mailbox->service_state = P9_SERVICE_SHUTDOWN;
      dsb();
      return 0;
    }
    mailbox->service_state = status == P9_RUNTIME_OK ?
                                 P9_SERVICE_COMPLETE : P9_SERVICE_FAULT;
    dsb();
  }
}
